#!/usr/bin/env python3
"""Check *data transfer consistency* between static HTML and V3 CSV.

This does not verify upstream NASA/JPL ephemerides, LOLA geometry or the
scientific validity of the model itself.
"""
import csv
import json
from pathlib import Path
import re
from collections import defaultdict

ROOT = Path(__file__).resolve().parent.parent
HTML = ROOT / 'index.html'
CSV = ROOT / 'science/data/v3/uc_bolge_saatlik_2163_satir.csv'
html = HTML.read_text(encoding='utf-8')
m = re.search(r'const D=(\{.*?\});\s*\n', html, re.DOTALL)
if not m:
    raise SystemExit('FAIL: embedded D JSON not found')
d = json.loads(m.group(1))
with CSV.open(newline='', encoding='utf-8-sig') as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 2163, f'Wrong CSV row count: {len(rows)}'
assert d['n'] == 721
by_site = defaultdict(list)
for row in rows:
    by_site[row['site_id']].append(row)
assert set(d['sites']) == set(by_site) == {'MM-01','MMP-02','NR-03'}
fields = [('sun','sun_center_unobstructed'),('earth','earth_center_unobstructed'),('both','both_centers_unobstructed')]
continuous = [('sunEl','sun_elevation_deg',0.00051),('sunAz','sun_azimuth_deg',0.051),('sunHz','sun_terrain_horizon_deg',0.00051),('earthEl','earth_elevation_deg',0.00051),('earthAz','earth_azimuth_deg',0.051),('earthHz','earth_terrain_horizon_deg',0.00051)]
for site, site_rows in by_site.items():
    assert len(site_rows) == 721, (site, len(site_rows))
    times = [r['time_utc'] for r in site_rows]
    assert times[0] == '2026-11-14T00:00:00Z'
    assert times[-1] == '2026-12-14T00:00:00Z'
    v = d['sites'][site]
    for key, column in fields:
        assert len(v['f'][key]) == 721
        assert all(int(x)==int(r[column]) for x,r in zip(v['f'][key],site_rows)), (site,key)
    for key, column, threshold in continuous:
        assert len(v[key]) == 721
        assert all(abs(float(x)-float(r[column])) <= threshold for x,r in zip(v[key],site_rows)), (site,key)
    print(site, 'sun/earth/both:', *(sum(map(int,v['f'][key])) for key,_ in fields))
print('PASS: 2163 rows, 3 sites, flags and rounded angles match the supplied CSV')
print('NOTE: This is NOT independent NASA/JPL Horizons or LOLA scientific validation.')
