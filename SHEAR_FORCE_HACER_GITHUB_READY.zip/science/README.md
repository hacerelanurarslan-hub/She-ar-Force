# Optional scientific Python workspace

The repository **root `index.html`** is the public GitHub Pages frontend. This folder contains the team's **earlier Python/Streamlit analysis app and scientific utilities**, including a V2 comparison whose model settings are distinct from V3.

## Start science pages (locally)

```bash
cd science
python -m pip install -r requirements.txt
python -m streamlit run Mission_Control.py
```

On Windows, `03_UYGULAMAYI_AC_WINDOWS.bat` creates an isolated virtual environment and launches Streamlit. The latest cinematic HTML is also copied here as `Cinematic_Navigator.html` so both home pages refer to the same dataset and design. Note that the Streamlit iframe height is static and may clip vertically on some narrow screens; use the public static homepage for the complete cinematic experience.

## Data

- `data/v3/uc_bolge_saatlik_2163_satir.csv` is the high-precision input data for 3 × 721 hourly sample points.
- `data/v3/uc_bolge_veri.json` contains the packaged sample-site record set.
- `data/v3/uc_bolge_yontem_karsilastirmasi.csv` compares interpolation approaches.
- `data/MM01_V2_ON_ANALIZ/` contains **older V2 research** using different near-field assumptions.

NASA data provenance and independent DEM validation remain **open scientific tasks**, not guaranteed by the repository. For methodology and limits see `../docs/METHODOLOGY.md`.
