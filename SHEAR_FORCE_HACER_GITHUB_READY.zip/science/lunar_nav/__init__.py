"""She'ar Force Lunar Landing Site Navigator — research prototype."""
__version__ = "1.0.0"
