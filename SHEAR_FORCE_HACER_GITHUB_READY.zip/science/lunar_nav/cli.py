"""Reproducible CLI: python -m lunar_nav.cli --source demo --output reports/demo_run."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

from lunar_nav.pipeline import run_scenario
from lunar_nav.sites import load_sites


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Lunar Site Navigator offline/real analysis")
    parser.add_argument("--source", choices=["demo", "nasa"], default="demo")
    parser.add_argument("--date", default="2026-11-14")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--step-minutes", type=int, default=60,
                        choices=[15, 30, 60, 120, 180, 360])
    parser.add_argument("--energy-weight", type=int, default=50)
    parser.add_argument("--sites", default="data/sites.csv")
    parser.add_argument("--output", default="reports/demo_run")
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    candidates = load_sites(root / args.sites)
    start = datetime.strptime(args.date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    result = run_scenario(
        sites=candidates[:3], start_utc=start, days=args.days,
        step_minutes=args.step_minutes,
        source="SYNTHETIC demo (offline)" if args.source == "demo" else "NASA/JPL Horizons (live)",
        energy_weight=args.energy_weight,
    )
    output = root / args.output
    output.mkdir(parents=True, exist_ok=True)
    result["metrics"].to_csv(output / "comparison.csv", index=False)
    pd.concat(result["details"].values(), ignore_index=True).to_csv(
        output / "ephemerides.csv", index=False)
    print("Source:", result["source"])
    print("Output directory:", output)
    print(result["metrics"][["site_id", "sunlight_pct", "earth_los_pct", "relative_score_pct"]]
          .to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
