"""Optional download helper for NASA GSFC PGDA LOLA South Pole site DEMs.

Each site URL comes from https://pgda.gsfc.nasa.gov/data/LOLA_5mpp/ .
Records provenance in a sidecar JSON with full sha256 and downloaded UTC time.
This helper checks file signature/size, not terrain accuracy.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import requests

DEM_URLS = {
    "001": "https://pgda.gsfc.nasa.gov/data/LOLA_5mpp/Site01/Site01_final_adj_5mpp_surf.tif",
    "007": "https://pgda.gsfc.nasa.gov/data/LOLA_5mpp/Site07/Site07_final_adj_5mpp_surf.tif",
    "011": "https://pgda.gsfc.nasa.gov/data/LOLA_5mpp/Site11/Site11_final_adj_5mpp_surf.tif",
}
MAX_FILE_BYTES = 750 * 1024 * 1024


class DemDownloadError(RuntimeError):
    pass


def download(site_id: str, output_dir: Path, session=None) -> tuple[Path, Path]:
    """Download specific researched NASA DEM, save TIFF and SHA256 JSON.

    Cache safety: never present a partial interrupted download as successful.
    """
    if site_id not in DEM_URLS:
        raise ValueError("Valid site IDs are 001, 007, 011")
    url = DEM_URLS[site_id]
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / Path(url).name
    meta_path = output_dir / f"{path.name}.provenance.json"
    temp_path = output_dir / f"{path.name}.partial"
    http = session if session is not None else requests
    total = 0
    digest = hashlib.sha256()
    try:
        with http.get(url, timeout=(15, 120), stream=True) as response:
            response.raise_for_status()
            content_type = response.headers.get("Content-Type", "").lower()
            if "text/html" in content_type or "application/json" in content_type:
                raise DemDownloadError(f"Not a raster response: {content_type}")
            with temp_path.open("wb") as dst:
                for block in response.iter_content(chunk_size=1024 * 1024):
                    if not block:
                        continue
                    total += len(block)
                    if total > MAX_FILE_BYTES:
                        raise DemDownloadError("DEM exceeded 750 MiB size safety cap")
                    digest.update(block)
                    dst.write(block)
        with temp_path.open("rb") as src:
            header = src.read(4)
        if total < 1024 or header not in (b"II*\x00", b"MM\x00*"):
            raise DemDownloadError(
                "Downloaded content does not look like a standard TIFF raster"
            )
        temp_path.replace(path)
        meta = {
            "site_id": site_id,
            "url": url,
            "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
            "size_bytes": total,
            "sha256": digest.hexdigest(),
            "provenance": "NASA/GSFC PGDA published LOLA 5 m raster; not independently field-validated",
            "scientific_status": "UNVALIDATED: inspect CRS, coverage, datum, elevations, raster uncertainties",
        }
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
        return path, meta_path
    except (requests.RequestException, OSError, DemDownloadError) as exc:
        temp_path.unlink(missing_ok=True)
        raise DemDownloadError(f"DEM download failed for {site_id}: {exc}") from exc


def main():
    parser = argparse.ArgumentParser(description="Download selected real NASA LOLA DEM")
    parser.add_argument("--site-id", choices=sorted(DEM_URLS), required=True)
    parser.add_argument("--output-dir", default="data/real_dem")
    options = parser.parse_args()
    dem_path, provenance_path = download(options.site_id, Path(options.output_dir))
    print(f"Downloaded {dem_path} (provenance: {provenance_path})")


if __name__ == "__main__":
    main()
