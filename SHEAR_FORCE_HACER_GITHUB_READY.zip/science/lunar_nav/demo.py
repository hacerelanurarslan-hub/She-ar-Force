"""SYNTHETIC demonstration curves (NOT NASA/Horizons data)."""
from __future__ import annotations
from datetime import datetime, timezone
from math import pi, sin, cos, radians
import pandas as pd
from lunar_nav.sites import LunarSite

EPOCH = datetime(2026, 11, 14, tzinfo=timezone.utc)


def synthetic_site(site: LunarSite, start_utc: datetime, end_utc: datetime,
                   step_minutes: int) -> pd.DataFrame:
    series = pd.date_range(start=start_utc, end=end_utc,
                           freq=f"{step_minutes}min", tz="UTC")
    lon = radians(site.longitude_east_deg)
    dist = site.latitude_deg + 90.0
    rows = []
    for stamp in series:
        days = (stamp.to_pydatetime() - EPOCH).total_seconds() / 86400.0
        sun_el = 1.0 + (0.9 + 0.3*dist)*sin(2*pi*days/29.53 + lon) + 0.6*sin(2*pi*days/365.25)
        earth_el = -0.5 + 0.8*dist*cos(lon) + 4.0*sin(2*pi*days/27.32 + lon/2)
        rows.append({
            "site_id": site.site_id,
            "timestamp_utc": stamp,
            "sun_az_deg": (110 + 12.2*days + site.longitude_east_deg) % 360,
            "sun_el_deg": sun_el,
            "earth_az_deg": (20 + 13.1*days + 0.4*site.longitude_east_deg) % 360,
            "earth_el_deg": earth_el,
            "source": "SYNTHETIC DEMO — NOT NASA DATA",
        })
    return pd.DataFrame(rows)
