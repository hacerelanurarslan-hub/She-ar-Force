"""NASA/JPL Horizons real topocentric Sun/Earth AZ/EL observations.

API documentation: https://ssd-api.jpl.nasa.gov/doc/horizons.html
Horizons manual: https://ssd.jpl.nasa.gov/horizons/manual.html

Notes:
  301 is the Moon. COMMAND=10 Sun, COMMAND=399 Earth.
  CENTER=coord@301, SITE_COORD=(east longitude, latitude, altitude km).
  QUANTITIES=4 is airless apparent azimuth/elevation (geometric local horizon).
  This API does not incorporate the actual local terrain horizon.
  We do not silently substitute synthetic samples on failed network requests.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone
from io import StringIO
import pandas as pd
import requests

from lunar_nav.sites import LunarSite

HORIZONS_URL = "https://ssd.jpl.nasa.gov/api/horizons.api"


class HorizonsError(RuntimeError):
    pass


def _check_dates(start: datetime, stop: datetime) -> None:
    if start.tzinfo is None or stop.tzinfo is None:
        raise ValueError("Start/stop must be timezone-aware UTC datetimes")
    if start.utcoffset().total_seconds() != 0 or stop.utcoffset().total_seconds() != 0:
        raise ValueError("Pass times in UTC")
    if stop <= start:
        raise ValueError("End must be later than start")


def query_params(body_id: str, site: LunarSite, start_utc: datetime,
                 stop_utc: datetime, step_minutes: int) -> dict[str, str]:
    _check_dates(start_utc, stop_utc)
    if body_id not in ("10", "399"):
        raise ValueError("Supported targets: Sun (10), Earth (399)")
    if step_minutes not in (15, 30, 60, 120, 180, 360):
        raise ValueError("Invalid sampling interval in minutes")
    if (stop_utc - start_utc).total_seconds() / (step_minutes * 60) > 5000:
        raise ValueError("Too many samples: shorten the range")
    return {
        "format": "json",
        "COMMAND": f"'{body_id}'",
        "MAKE_EPHEM": "'YES'",
        "EPHEM_TYPE": "'OBSERVER'",
        "OBJ_DATA": "'NO'",
        "CENTER": "'coord@301'",
        "COORD_TYPE": "'GEODETIC'",
        # Moon uses positive east-longitude. Convert signed west-negative
        # research-paper values into Horizons' unambiguous 0..360° E form.
        "SITE_COORD": (f"'{site.longitude_east_deg % 360:.8f},"
                       f"{site.latitude_deg:.8f},{site.altitude_km:.6f}'"),
        "START_TIME": f"'{start_utc:%Y-%m-%d %H:%M}'",
        "STOP_TIME": f"'{stop_utc:%Y-%m-%d %H:%M}'",
        "STEP_SIZE": f"'{step_minutes}m'",
        "QUANTITIES": "'4'",
        "TIME_TYPE": "'UT'",
        "TIME_ZONE": "'+00:00'",
        "TIME_DIGITS": "'MINUTES'",
        "CAL_FORMAT": "'CAL'",
        "CSV_FORMAT": "'YES'",
        "APPARENT": "'AIRLESS'",
        "ANG_FORMAT": "'DEG'",
        "SKIP_DAYLT": "'NO'",
    }


def parse_horizons_csv(raw_text: str) -> pd.DataFrame:
    """Only parse QUANTITIES=4 and CAL_FORMAT=CAL responses.

    The CSV date may be followed by an indicator/flag. We read the first
    *two numeric values after the date* as azimuth and elevation; reject
    incomplete lines instead of using stale/incorrect values.
    """
    if "$$SOE" not in raw_text or "$$EOE" not in raw_text:
        tail = raw_text[:300].replace("\n", " ")
        raise HorizonsError(f"Ephemeris start/end markers missing: {tail}")
    raw_block = raw_text.split("$$SOE", 1)[1].split("$$EOE", 1)[0]
    records = []
    for fields in csv.reader(StringIO(raw_block)):
        if not fields or not fields[0].strip():
            continue
        stamp_text = fields[0].strip().removeprefix("A.D. ")
        try:
            stamp = datetime.strptime(stamp_text, "%Y-%b-%d %H:%M").replace(
                tzinfo=timezone.utc)
        except ValueError as exc:
            raise HorizonsError(f"Bad date column in Horizons CSV: {stamp_text}") from exc
        numeric = []
        for item in fields[1:]:
            value = item.strip()
            if not value or value.lower() in {"n.a.", "nan"}:
                continue
            try:
                numeric.append(float(value))
            except ValueError:
                pass  # e.g. daylight status, marker
        if len(numeric) != 2:
            raise HorizonsError(f"Expected 2 AZ/EL values for {stamp_text}; got {numeric}")
        az, el = numeric
        if not 0 <= az <= 360 or not -90 <= el <= 90:
            raise HorizonsError(f"Invalid AZ/EL in JPL response for {stamp_text}")
        records.append({"timestamp_utc": stamp, "az_deg": az, "el_deg": el})
    if len(records) < 2:
        raise HorizonsError("Horizons needs at least two time samples")
    df = pd.DataFrame(records)
    df["timestamp_utc"] = pd.to_datetime(df["timestamp_utc"], utc=True)
    if df["timestamp_utc"].duplicated().any() or not df["timestamp_utc"].is_monotonic_increasing:
        raise HorizonsError("Horizons timestamps were duplicated/out of order")
    return df


def fetch_body(body_id: str, site: LunarSite, start_utc: datetime,
               stop_utc: datetime, step_minutes: int = 60,
               session: requests.Session | None = None) -> pd.DataFrame:
    params = query_params(body_id, site, start_utc, stop_utc, step_minutes)
    get = session.get if session is not None else requests.get
    try:
        response = get(HORIZONS_URL, params=params, timeout=45,
                       headers={"User-Agent": "ShearForce-LunarNavigator/1.0 (educational)"})
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise HorizonsError(f"NASA/JPL Horizons service unavailable: {exc}") from exc
    if not isinstance(payload, dict):
        raise HorizonsError("Horizons did not return a JSON object")
    if payload.get("error"):
        raise HorizonsError(f"JPL Horizons reported: {str(payload['error'])[:900]}")
    if not isinstance(payload.get("result"), str):
        raise HorizonsError("JPL Horizons JSON did not include a text result")
    df = parse_horizons_csv(payload["result"])
    expected = pd.date_range(start=start_utc, end=stop_utc,
                             freq=f"{step_minutes}min", tz="UTC")
    # Fail rather than reporting a partial day as a fully observed period.
    if not pd.DatetimeIndex(df["timestamp_utc"]).equals(expected):
        raise HorizonsError(
            f"Wrong time grid: expected {len(expected)} rows, received {len(df)}. "
            "Check Horizons time precision/flags."
        )
    return df


def fetch_site(site: LunarSite, start_utc: datetime, stop_utc: datetime,
               step_minutes: int = 60,
               session: requests.Session | None = None) -> pd.DataFrame:
    sun = fetch_body("10", site, start_utc, stop_utc, step_minutes, session).rename(
        columns={"az_deg": "sun_az_deg", "el_deg": "sun_el_deg"})
    earth = fetch_body("399", site, start_utc, stop_utc, step_minutes, session).rename(
        columns={"az_deg": "earth_az_deg", "el_deg": "earth_el_deg"})
    merged = sun.merge(earth, on="timestamp_utc", how="inner", validate="one_to_one")
    if len(merged) != len(sun) or len(merged) != len(earth):
        raise HorizonsError("Sun/Earth observations do not share the same timestamps")
    merged["site_id"] = site.site_id
    merged["source"] = "NASA/JPL HORIZONS (live)"
    return merged
