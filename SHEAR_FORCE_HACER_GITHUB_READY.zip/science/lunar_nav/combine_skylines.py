"""Validate and merge site-specific skyline CSVs for Streamlit file uploader."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from lunar_nav.terrain import load_skyline


def combine(paths: list[str | Path], output_path: str | Path) -> pd.DataFrame:
    if not paths:
        raise ValueError("At least one skyline CSV is required")
    frames = [pd.read_csv(path, dtype={"site_id": "string"}) for path in paths]
    merged = pd.concat(frames, ignore_index=True)
    profiles = load_skyline(merged.to_csv(index=False).encode("utf-8"))
    site_ids = merged["site_id"].astype(str).unique().tolist()
    if len(site_ids) != len(paths):
        raise ValueError("Provide exactly one skyline profile file per site")
    normalized = pd.concat(
        [data.assign(site_id=site_id) for site_id, data in profiles.items()],
        ignore_index=True,
    )
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized.to_csv(path, index=False)
    return normalized


def main():
    parser = argparse.ArgumentParser(description="Merge site-specific skyline CSV files")
    parser.add_argument("--input", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    options = parser.parse_args()
    result = combine(options.input, options.output)
    print(f"Saved {len(result)} skyline directions to {options.output}")


if __name__ == "__main__":
    main()
