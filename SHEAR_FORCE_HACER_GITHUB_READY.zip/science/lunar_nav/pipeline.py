"""Headless scenario runner shared by Streamlit and CLI."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
import pandas as pd

from lunar_nav.demo import synthetic_site
from lunar_nav.horizons import fetch_site
from lunar_nav.science import rank_sites, summarize_site
from lunar_nav.sites import LunarSite


def run_scenario(sites: list[LunarSite], start_utc: datetime, days: int,
                 step_minutes: int, source: str, energy_weight: int,
                 skylines: dict | None = None, imports: dict | None = None,
                 fetch_fn=None) -> dict:
    if not 1 <= len(sites) <= 3:
        raise ValueError("Choose 1–3 sites")
    if not 1 <= days <= 30:
        raise ValueError("Analysis must last 1–30 days")
    if step_minutes not in (15, 30, 60, 120, 180, 360):
        raise ValueError("Invalid sampling interval")
    if start_utc.tzinfo is None or start_utc.utcoffset().total_seconds() != 0:
        raise ValueError("UTC datetime required")
    stop_utc = start_utc + timedelta(days=days)
    skylines = skylines or {}
    imports = imports or {}
    fetch_fn = fetch_fn or fetch_site
    details, windows, summaries = {}, {}, []
    for site in sites:
        if source == "NASA/JPL Horizons (live)":
            df = fetch_fn(site, start_utc, stop_utc, step_minutes)
        elif source == "SYNTHETIC demo (offline)":
            df = synthetic_site(site, start_utc, stop_utc, step_minutes)
        elif source == "Import CSV (unverified)":
            if site.site_id not in imports:
                raise ValueError(f"CSV does not include site {site.site_id}")
            df = imports[site.site_id]
            df = df.loc[(df["timestamp_utc"] >= start_utc) &
                        (df["timestamp_utc"] <= stop_utc)].copy()
            expected = pd.date_range(start=start_utc, end=stop_utc,
                                     freq=f"{step_minutes}min", tz="UTC")
            if not pd.DatetimeIndex(df["timestamp_utc"]).equals(expected):
                raise ValueError(
                    f"CSV for {site.site_id} needs the complete requested time grid "
                    f"({len(expected)} timestamps, every {step_minutes} minutes)"
                )
        else:
            raise ValueError(f"Unknown source: {source}")
        metrics, corrected, windows_by_type = summarize_site(df, skylines.get(site.site_id))
        corrected["site_id"] = site.site_id
        corrected["site_name"] = site.name
        corrected["source"] = df["source"].iloc[0]
        details[site.site_id] = corrected
        windows[site.site_id] = windows_by_type
        summaries.append({"site_id": site.site_id, "site_name": site.name,
                          "latitude_deg": site.latitude_deg,
                          "longitude_east_deg": site.longitude_east_deg,
                          **metrics})
    return {
        "source": source, "sites": sites, "start": start_utc,
        "end": stop_utc, "step_minutes": step_minutes,
        "energy_weight": energy_weight, "skyline_provided": bool(skylines),
        "metrics": rank_sites(pd.DataFrame(summaries), energy_weight),
        "details": details, "windows": windows,
    }
