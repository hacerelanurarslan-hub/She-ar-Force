"""Optional lunar DEM → local terrain horizon (skyline) extractor.

Requires additional packages: rasterio and pyproj.
Input DEM must have a valid, *lunar* georeferenced CRS and elevations (metres)
relative to the nominal lunar 1,737,400 m reference sphere. The tool checks
CRS radius but cannot independently verify DEM provenance/datum or quality.

EXAMPLE:
python -m lunar_nav.dem_skyline --dem /path/to/lola_south_pole.tif \
  --site-id A --lat -89 --lon 0 --range-km 25 --step-m 200 \
  --az-step-deg 5 --output data/real_A_skyline.csv
"""
from __future__ import annotations
import argparse
from math import asin, atan2, cos, degrees, radians, sin
from pathlib import Path
import numpy as np
import pandas as pd

MOON_RADIUS_M = 1_737_400.0


class DemSkylineError(ValueError):
    pass


def destination(lat_deg: float, lon_deg: float, az_deg: float,
                distance_m: float, radius_m: float = MOON_RADIUS_M) -> tuple[float, float]:
    """Great-circle destination; bearing azimuth clockwise from geodetic North."""
    lat0, lon0, bearing = map(radians, (lat_deg, lon_deg, az_deg))
    central = distance_m / radius_m
    lat = asin(sin(lat0) * cos(central) + cos(lat0) * sin(central) * cos(bearing))
    lon = lon0 + atan2(sin(bearing) * sin(central) * cos(lat0),
                       cos(central) - sin(lat0) * sin(lat))
    return degrees(lat), ((degrees(lon) + 180) % 360) - 180


def elevation_to_target(distance_m: float, site_height_m: float,
                        target_height_m: float, mast_height_m: float,
                        radius_m: float = MOON_RADIUS_M) -> float:
    """Line of sight above the local spherical tangent plane, including curvature."""
    central = distance_m / radius_m
    origin_r = radius_m + site_height_m + mast_height_m
    target_r = radius_m + target_height_m
    vertical = target_r * cos(central) - origin_r
    tangential = target_r * sin(central)
    return degrees(atan2(vertical, tangential))


def extract_skyline(dem_path: str | Path, site_id: str, lat_deg: float,
                    lon_deg: float, range_km: float = 25.0,
                    step_m: float = 200.0, az_step_deg: int = 5,
                    mast_height_m: float = 1.5) -> pd.DataFrame:
    if not -90 <= lat_deg <= 90 or not -360 <= lon_deg <= 360:
        raise DemSkylineError("Invalid lunar coordinates")
    if not 0.5 <= range_km <= 100:
        raise DemSkylineError("range_km must be 0.5–100")
    if not 5 <= step_m <= 2000:
        raise DemSkylineError("step_m must be 5–2000")
    if az_step_deg not in (1, 2, 5, 10, 15, 30):
        raise DemSkylineError("az_step_deg must be 1, 2, 5, 10, 15, or 30")
    if not 0 <= mast_height_m <= 50:
        raise DemSkylineError("Mast height must be 0–50 m")
    try:
        import rasterio
        from pyproj import CRS, Transformer
    except ImportError as exc:
        raise DemSkylineError("Install optional dependencies: pip install rasterio pyproj") from exc
    moon_geographic = CRS.from_proj4(
        "+proj=longlat +a=1737400 +b=1737400 +no_defs +type=crs")
    with rasterio.open(dem_path) as src:
        if src.crs is None:
            raise DemSkylineError("DEM has no CRS: cannot locate lunar site")
        dest_crs = CRS.from_user_input(src.crs)
        radius = dest_crs.ellipsoid.semi_major_metre
        if not 1_700_000 <= radius <= 1_800_000:
            raise DemSkylineError(
                f"DEM CRS radius {radius:.0f} m does not look lunar; check CRS")
        converter = Transformer.from_crs(moon_geographic, dest_crs, always_xy=True)

        def get_heights(lat_lon):
            pts = [converter.transform(lon, lat) for lat, lon in lat_lon]
            raw = np.array([a[0] for a in src.sample(pts, masked=True)], dtype=float)
            if src.nodata is not None:
                raw[np.isclose(raw, src.nodata)] = np.nan
            raw[~np.isfinite(raw)] = np.nan
            return raw

        origin = get_heights([(lat_deg, lon_deg)])[0]
        if not np.isfinite(origin):
            raise DemSkylineError("Site lies outside valid DEM pixels")
        distances = np.arange(step_m, range_km * 1000 + 1e-6, step_m)
        if len(distances) < 2:
            raise DemSkylineError("Need multiple distances along each bearing")
        rows = []
        for az in range(0, 360, az_step_deg):
            positions = [destination(lat_deg, lon_deg, az, d) for d in distances]
            heights = get_heights(positions)
            valid = np.isfinite(heights)
            if not valid.any():
                raise DemSkylineError(f"No terrain data along bearing {az}°")
            if valid.mean() < 0.8:
                raise DemSkylineError(
                    f"Insufficient DEM coverage along bearing {az}° "
                    f"({valid.mean():.0%}); shorten search radius or use bigger DEM")
            angles = [elevation_to_target(float(d), float(origin), float(h),
                                          mast_height_m)
                      for d, h in zip(distances[valid], heights[valid])]
            best = int(np.argmax(angles))
            rows.append({"site_id": site_id, "az_deg": float(az),
                         "horizon_el_deg": angles[best],
                         "dominant_obstacle_distance_m": distances[valid][best],
                         "dem_source_file": Path(dem_path).name})
    return pd.DataFrame(rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Generate terrain skyline from lunar DEM")
    parser.add_argument("--dem", required=True)
    parser.add_argument("--site-id", required=True)
    parser.add_argument("--lat", type=float, required=True)
    parser.add_argument("--lon", type=float, required=True)
    parser.add_argument("--range-km", type=float, default=25)
    parser.add_argument("--step-m", type=float, default=200)
    parser.add_argument("--az-step-deg", type=int, default=5)
    parser.add_argument("--mast-height-m", type=float, default=1.5)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    result = extract_skyline(
        args.dem, args.site_id, args.lat, args.lon, args.range_km,
        args.step_m, args.az_step_deg, args.mast_height_m)
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(path, index=False)
    print(f"Saved {len(result)} azimuth directions to {path}")
    print("IMPORTANT: Confirm DEM georeferencing, datum and dataset provenance!")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
