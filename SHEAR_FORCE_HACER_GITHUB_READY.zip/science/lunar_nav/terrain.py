"""Azimuth-dependent skyline correction (optional, user-supplied CSV).

A skyline means the *elevation angle of the terrain horizon*, not the DEM
height in metres. Values should be independently produced from a documented
LOLA/LROC terrain DEM, ideally with uncertainty and coordinate registration.
The bundled FORMAT_EXAMPLE values are invented. They are NOT NASA terrain data.
"""
from __future__ import annotations
from io import BytesIO
import numpy as np
import pandas as pd


class TerrainError(ValueError):
    pass


def load_skyline(content: bytes) -> dict[str, pd.DataFrame]:
    try:
        df = pd.read_csv(BytesIO(content), dtype={"site_id": "string"})
    except Exception as exc:
        raise TerrainError(f"Could not read skyline CSV: {exc}") from exc
    required = {"site_id", "az_deg", "horizon_el_deg"}
    if not required.issubset(df.columns):
        raise TerrainError(f"Skyline CSV requires {sorted(required)}")
    if df.empty or df[list(required)].isna().any().any():
        raise TerrainError("Skyline must have complete rows")
    for column in ("az_deg", "horizon_el_deg"):
        df[column] = pd.to_numeric(df[column], errors="coerce")
        if not np.isfinite(df[column].to_numpy(dtype=float)).all():
            raise TerrainError(f"Non-numeric or infinite {column} value")
    if not df["az_deg"].between(0, 360).all():
        raise TerrainError("Azimuth must be 0–360 degrees")
    if not df["horizon_el_deg"].between(-90, 90).all():
        raise TerrainError("Horizon elevation must be -90 to 90 degrees")
    df["az_deg"] %= 360
    result: dict[str, pd.DataFrame] = {}
    for site_id, sub in df.groupby("site_id", sort=False):
        sub = sub.sort_values("az_deg").reset_index(drop=True)
        if len(sub) < 2 or sub["az_deg"].duplicated().any():
            raise TerrainError(f"Site {site_id}: need 2+ unique azimuths")
        result[str(site_id)] = sub[["az_deg", "horizon_el_deg"]]
    return result


def horizon_at_azimuth(azimuth_deg: np.ndarray | pd.Series,
                       skyline: pd.DataFrame | None) -> np.ndarray:
    az = np.asarray(azimuth_deg, dtype=float)
    if skyline is None:
        return np.zeros_like(az)
    xp = skyline["az_deg"].to_numpy(dtype=float)
    fp = skyline["horizon_el_deg"].to_numpy(dtype=float)
    # Wrap boundary properly: 359° interpolates between last point and first at 360°.
    xp = np.concatenate(([xp[-1] - 360], xp, [xp[0] + 360]))
    fp = np.concatenate(([fp[-1]], fp, [fp[0]]))
    return np.interp(np.mod(az, 360), xp, fp)
