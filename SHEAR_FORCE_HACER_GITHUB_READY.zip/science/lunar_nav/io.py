"""Import and export reproducible time-series data with explicit provenance."""
from __future__ import annotations
from io import BytesIO
import pandas as pd
from lunar_nav.science import validate_ephemeris

COLUMNS = {"site_id", "timestamp_utc", "sun_az_deg", "sun_el_deg", "earth_az_deg", "earth_el_deg"}


def load_observations(content: bytes) -> dict[str, pd.DataFrame]:
    try:
        frame = pd.read_csv(BytesIO(content), dtype={"site_id": "string"})
    except Exception as exc:
        raise ValueError(f"Cannot read observations CSV: {exc}") from exc
    missing = COLUMNS - set(frame.columns)
    if missing:
        raise ValueError(f"Observations CSV missing columns: {sorted(missing)}")
    if frame.empty or frame["site_id"].isna().any():
        raise ValueError("Observations CSV must have site IDs")
    result = {}
    for site_id, rows in frame.groupby("site_id"):
        rows = validate_ephemeris(rows)
        rows["site_id"] = str(site_id)
        # Imported data could be edited; never trust source column from user.
        rows["source"] = "IMPORTED CSV — provenance unverified"
        result[str(site_id)] = rows
    return result
