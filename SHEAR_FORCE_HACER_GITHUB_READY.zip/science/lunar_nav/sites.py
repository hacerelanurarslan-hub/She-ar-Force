"""Lunar reference-ellipsoid observer coordinates (east-positive longitude)."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import pandas as pd

@dataclass(frozen=True)
class LunarSite:
    site_id: str
    name: str
    latitude_deg: float
    longitude_east_deg: float
    altitude_km: float = 0.0
    provenance: str = "USER-PROVIDED / UNVERIFIED"

    def __post_init__(self) -> None:
        if not self.site_id or not self.site_id.strip():
            raise ValueError("site_id cannot be empty")
        if not -90 <= self.latitude_deg <= 90:
            raise ValueError("latitude_deg must be between -90 and 90")
        if not -360 <= self.longitude_east_deg <= 360:
            raise ValueError("longitude_east_deg must be between -360 and 360")
        if not -20 <= self.altitude_km <= 50:
            raise ValueError("Check altitude_km, measured from lunar reference ellipsoid")


def load_sites(path: str | Path) -> list[LunarSite]:
    frame = pd.read_csv(path, keep_default_na=False, dtype={"site_id": "string"})
    columns = {"site_id", "name", "latitude_deg", "longitude_east_deg", "altitude_km"}
    if not columns.issubset(frame.columns):
        raise ValueError(f"Site CSV needs {sorted(columns)}")
    if frame["site_id"].duplicated().any() or frame.empty:
        raise ValueError("Site CSV must contain unique site IDs")
    result = []
    for row in frame.to_dict("records"):
        result.append(LunarSite(
            site_id=str(row["site_id"]), name=str(row["name"]),
            latitude_deg=float(row["latitude_deg"]),
            longitude_east_deg=float(row["longitude_east_deg"]),
            altitude_km=float(row["altitude_km"]),
            provenance=str(row.get("provenance", "USER-PROVIDED / UNVERIFIED")),
        ))
    return result
