"""Visibility, energy proxy, comparison metrics; no hidden assumptions.

- Body *center* above azimuth-dependent skyline (ideal zero horizon if absent).
- Linearly interpolated crossings on the sample grid. Near-horizon accuracy is
  limited by interval length and terrain resolution.
- Solar power proxy is horizontal-panel sin(elevation) during SUN VISIBILITY,
  integrated over time (unitless average, not kWh).
- Direct Earth visibility is geometric line of sight only (not guaranteed link).
"""
from __future__ import annotations
from math import radians, sin
import numpy as np
import pandas as pd

from lunar_nav.terrain import horizon_at_azimuth

COLS = {"timestamp_utc", "sun_az_deg", "sun_el_deg", "earth_az_deg", "earth_el_deg"}


def validate_ephemeris(df: pd.DataFrame) -> pd.DataFrame:
    missing = COLS - set(df.columns)
    if missing:
        raise ValueError(f"Missing ephemeris fields: {sorted(missing)}")
    frame = df.copy()
    frame["timestamp_utc"] = pd.to_datetime(frame["timestamp_utc"], utc=True, errors="raise")
    for col in COLS - {"timestamp_utc"}:
        frame[col] = pd.to_numeric(frame[col], errors="raise")
        if not np.isfinite(frame[col]).all():
            raise ValueError(f"Invalid {col} values")
    for col in ("sun_el_deg", "earth_el_deg"):
        if not frame[col].between(-90, 90).all():
            raise ValueError(f"Elevation out of -90..90: {col}")
    for col in ("sun_az_deg", "earth_az_deg"):
        if not frame[col].between(0, 360).all():
            raise ValueError(f"Azimuth out of 0..360: {col}")
    frame.sort_values("timestamp_utc", inplace=True)
    frame.reset_index(drop=True, inplace=True)
    if len(frame) < 2 or frame["timestamp_utc"].duplicated().any():
        raise ValueError("Need 2+ distinct timestamps")
    return frame


def add_clearance(df: pd.DataFrame,
                  skyline: pd.DataFrame | None = None) -> pd.DataFrame:
    """Positive clearance means unobstructed body center in this approximation."""
    frame = validate_ephemeris(df)
    frame["sun_horizon_deg"] = horizon_at_azimuth(frame["sun_az_deg"], skyline)
    frame["earth_horizon_deg"] = horizon_at_azimuth(frame["earth_az_deg"], skyline)
    frame["sun_clearance_deg"] = frame["sun_el_deg"] - frame["sun_horizon_deg"]
    frame["earth_clearance_deg"] = frame["earth_el_deg"] - frame["earth_horizon_deg"]
    return frame


def _clipped_segment(t0: pd.Timestamp, t1: pd.Timestamp, v0: float, v1: float):
    """Positive duration of a linearly interpolated clearance signal."""
    if v0 >= 0 and v1 >= 0:
        return t0, t1
    if v0 <= 0 and v1 <= 0:
        return None
    fraction = -v0 / (v1 - v0)
    crossing = t0 + (t1 - t0) * fraction
    return (crossing, t1) if v1 > 0 else (t0, crossing)


def _merge_segments(parts):
    merged = []
    for start, end in parts:
        if start >= end:
            continue
        if merged and start <= merged[-1][1] + pd.Timedelta(microseconds=1):
            merged[-1] = merged[-1][0], max(merged[-1][1], end)
        else:
            merged.append((start, end))
    return merged


def visibility_windows(frame: pd.DataFrame, clearance_col: str):
    if clearance_col not in ("sun_clearance_deg", "earth_clearance_deg"):
        raise ValueError("Choose sun_clearance_deg or earth_clearance_deg")
    if not {"timestamp_utc", clearance_col}.issubset(frame.columns):
        raise ValueError("Clearance fields missing; call add_clearance first")
    parts = []
    for i in range(len(frame) - 1):
        a, b = frame.iloc[i], frame.iloc[i + 1]
        clip = _clipped_segment(a.timestamp_utc, b.timestamp_utc,
                                float(a[clearance_col]), float(b[clearance_col]))
        if clip:
            parts.append(clip)
    return _merge_segments(parts)


def intersect_windows(a, b):
    overlaps = []
    i = j = 0
    while i < len(a) and j < len(b):
        start, end = max(a[i][0], b[j][0]), min(a[i][1], b[j][1])
        if start < end:
            overlaps.append((start, end))
        if a[i][1] <= b[j][1]:
            i += 1
        else:
            j += 1
    return _merge_segments(overlaps)


def outage_windows(windows, start, end):
    result = []
    left = start
    for begin, finish in windows:
        if begin > left:
            result.append((left, begin))
        left = max(left, finish)
    if left < end:
        result.append((left, end))
    return result


def duration_h(pair) -> float:
    return (pair[1] - pair[0]).total_seconds() / 3600.0


def total_h(windows) -> float:
    return sum(map(duration_h, windows))


def _sun_energy_proxy(frame: pd.DataFrame) -> float:
    """Trapezoidal integration only over geometrically lit sub-intervals."""
    area = 0.0
    elapsed = duration_h((frame.iloc[0].timestamp_utc, frame.iloc[-1].timestamp_utc))
    for i in range(len(frame) - 1):
        a, b = frame.iloc[i], frame.iloc[i + 1]
        clipped = _clipped_segment(a.timestamp_utc, b.timestamp_utc,
                                   float(a.sun_clearance_deg), float(b.sun_clearance_deg))
        if clipped is None:
            continue
        t0, t1 = clipped
        dt_all = duration_h((a.timestamp_utc, b.timestamp_utc))
        dt_lit = duration_h((t0, t1))
        if dt_lit <= 0:
            continue
        frac0 = duration_h((a.timestamp_utc, t0)) / dt_all
        frac1 = duration_h((a.timestamp_utc, t1)) / dt_all
        el0 = a.sun_el_deg + frac0 * (b.sun_el_deg - a.sun_el_deg)
        el1 = a.sun_el_deg + frac1 * (b.sun_el_deg - a.sun_el_deg)
        p0 = max(0.0, sin(radians(el0)))
        p1 = max(0.0, sin(radians(el1)))
        area += dt_lit * (p0 + p1) / 2
    return area / elapsed


def summarize_site(df: pd.DataFrame,
                   skyline: pd.DataFrame | None = None) -> tuple[dict, pd.DataFrame, dict]:
    data = add_clearance(df, skyline)
    sw = visibility_windows(data, "sun_clearance_deg")
    ew = visibility_windows(data, "earth_clearance_deg")
    bw = intersect_windows(sw, ew)
    outages = outage_windows(ew, data.iloc[0].timestamp_utc, data.iloc[-1].timestamp_utc)
    duration = duration_h((data.iloc[0].timestamp_utc, data.iloc[-1].timestamp_utc))
    s, e, b = total_h(sw), total_h(ew), total_h(bw)
    metrics = {
        "duration_h": duration,
        "sunlight_h": s,
        "sunlight_pct": min(100.0, 100 * s / duration),
        "earth_los_h": e,
        "earth_los_pct": min(100.0, 100 * e / duration),
        "dual_visibility_h": b,
        "dual_visibility_pct": min(100.0, 100 * b / duration),
        "longest_earth_window_h": max((duration_h(w) for w in ew), default=0.0),
        "longest_outage_h": max((duration_h(w) for w in outages), default=0.0),
        "mean_solar_proxy": _sun_energy_proxy(data),
        "terrain_profile_applied": skyline is not None,
    }
    return metrics, data, {"Sun": sw, "Earth LOS": ew, "Both": bw, "Earth outage": outages}


def rank_sites(metrics: pd.DataFrame, energy_weight: int) -> pd.DataFrame:
    if not 0 <= energy_weight <= 100:
        raise ValueError("Weight must be 0..100")
    required = {"site_id", "mean_solar_proxy", "earth_los_pct"}
    if not required.issubset(metrics.columns) or metrics.empty:
        raise ValueError("Missing metrics for comparison")
    df = metrics.copy()
    max_power = float(df["mean_solar_proxy"].max())
    df["relative_solar_pct"] = (
        100 * df["mean_solar_proxy"] / max_power if max_power > 0 else 0.0
    )
    w = energy_weight / 100.0
    df["relative_score_pct"] = (
        w * df["relative_solar_pct"] + (1-w) * df["earth_los_pct"]
    )
    return df.sort_values(["relative_score_pct", "site_id"],
                          ascending=[False, True]).reset_index(drop=True)
