# AI ASSISTANCE: Generated and iteratively edited with OpenAI ChatGPT (GPT-6).
# Research team must independently validate ephemeris and DEM science before submission.
"""She'ar Force — Lunar Landing Site Navigator (Streamlit research prototype).

Run: python -m streamlit run app.py
Data modes are explicitly separated; NO unannounced demo fallback.
"""
from __future__ import annotations
import json
from datetime import date, datetime, time, timezone
from pathlib import Path
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from lunar_nav.horizons import HorizonsError, fetch_site
from lunar_nav.io import load_observations
from lunar_nav.pipeline import run_scenario
from lunar_nav.science import duration_h
from lunar_nav.sites import LunarSite, load_sites
from lunar_nav.terrain import TerrainError, load_skyline

ROOT = Path(__file__).resolve().parent
SOURCES = ["SYNTHETIC demo (offline)", "NASA/JPL Horizons (live)", "Import CSV (unverified)",
           "MM-01 V2 — NASA/LOLA preliminary study (Team Member 2)"]
PERSON1_MODE = SOURCES[3]
V2_FILES = {
    "Bilinear (recommended preliminary model)": (ROOT / "data" / "MM01_import_bilinear.csv", ROOT / "data" / "MM01_skyline_bilinear.csv"),
    "Nearest pixel (sensitivity check)": (ROOT / "data" / "MM01_import_nearest.csv", ROOT / "data" / "MM01_skyline_nearest.csv"),
}
LOCAL_SUMMARY = ROOT / "data" / "MM01_V2_ozet.json"
PERSON1_READY = all(ep.is_file() and sky.is_file() for ep, sky in V2_FILES.values())

st.set_page_config(page_title="She'ar Force | Lunar Landing Navigator",
                   page_icon="🌙", layout="wide", initial_sidebar_state="expanded")


@st.cache_data(ttl=6*3600, show_spinner=False)
def cached_fetch(site: LunarSite, start: datetime, stop: datetime, step: int):
    return fetch_site(site, start, stop, step)


def read_runs(sites, start_dates, days, step, source, energy_weight, skyline, imports):
    return [run_scenario(
        sites, datetime.combine(d, time.min, tzinfo=timezone.utc), days,
        step, source, energy_weight, skyline, imports, cached_fetch,
    ) for d in start_dates]


def create_line_figure(frame: pd.DataFrame, terrain_applied: bool):
    fig = go.Figure()
    fig.add_hline(y=0, line_dash="dash", line_color="gray",
                  annotation_text="Ideal horizon 0°")
    for name, column, color in (
        ("Sun", "sun_el_deg", "#F5C15D"),
        ("Earth", "earth_el_deg", "#77CEFF"),
    ):
        fig.add_trace(go.Scatter(x=frame.timestamp_utc, y=frame[column],
                                 mode="lines", name=f"{name} elevation",
                                 line={"color": color, "width": 2.7}))
    if terrain_applied:
        fig.add_trace(go.Scatter(x=frame.timestamp_utc, y=frame.sun_horizon_deg,
                                 mode="lines", name="Sun-direction terrain horizon",
                                 line={"color": "#C78DF0", "dash": "dot"}))
        fig.add_trace(go.Scatter(x=frame.timestamp_utc, y=frame.earth_horizon_deg,
                                 mode="lines", name="Earth-direction terrain horizon",
                                 line={"color": "#60D29A", "dash": "dot"}))
    fig.update_layout(height=370, margin=dict(l=8, r=8, t=12, b=12),
                      xaxis_title="Time (UTC)", yaxis_title="Elevation (degrees)",
                      legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0),
                      hovermode="x unified")
    return fig


def create_sky_figure(frame: pd.DataFrame):
    fig = go.Figure()
    for label, az, elev, color in (
        ("Sun", "sun_az_deg", "sun_el_deg", "#F5C15D"),
        ("Earth", "earth_az_deg", "earth_el_deg", "#77CEFF"),
    ):
        fig.add_trace(go.Scatterpolar(
            theta=frame[az], r=90.0-frame[elev],
            name=label, mode="lines+markers", marker=dict(size=4),
            line=dict(color=color, width=2),
            customdata=frame[["timestamp_utc", elev]].astype(str).to_numpy(),
            hovertemplate="Azimuth %{theta:.1f}° / elevation %{customdata[1]}°<extra>"
                          + label + "</extra>",
        ))
    fig.add_trace(go.Scatterpolar(
        theta=list(range(361)), r=[90]*361, mode="lines",
        line=dict(color="gray", dash="dash", width=1.8),
        name="Ideal 0° horizon", hoverinfo="skip",
    ))
    fig.update_layout(height=390, margin=dict(l=28, r=28, t=40, b=28),
                      polar=dict(radialaxis=dict(range=[0, 120],
                                                 tickvals=[0, 30, 60, 90, 120],
                                                 ticktext=["Zenith", "60° el", "30° el",
                                                           "0° horizon", "−30° el"]),
                                 angularaxis=dict(direction="clockwise", rotation=90)),
                      legend=dict(orientation="h", y=-0.11, x=0),
                      title="Azimuth vs elevation (center = zenith)")
    return fig


def windows_table(windows: dict):
    rows = []
    for name, intervals in windows.items():
        for begin, end in intervals:
            rows.append({"window": name, "start_utc": begin,
                         "end_utc": end, "duration_h": duration_h((begin, end))})
    return pd.DataFrame(rows, columns=["window", "start_utc", "end_utc", "duration_h"])


st.caption("SHE'AR FORCE · NASA SPACE APPS CHALLENGE 2026 · INDEPENDENT RESEARCH PROTOTYPE")
st.title("🌙 Lunar Landing Site Navigator")
st.page_link("pages/00_Mission_Brief.py", label="✨ NEW · OPEN JURY MISSION BRIEF", icon="📋")
st.page_link("pages/01_Three_Site_V3.py", label="🌕 OPEN THE V3 THREE-SITE COMPARISON", icon="🌕")
st.caption("MM-01 V2 and three-site V3 are different models; do not interpret their percentages as results from an identical scenario.")
st.write("**Plan smarter near the Moon's south pole.** Compare Sun and Earth positions, "
         "potential illumination, geometric communication windows, and mission dates.")

available = load_sites(ROOT / "data" / "sites.csv")
by_id = {s.site_id: s for s in available}

with st.sidebar:
    st.header("Mission controls")
    with st.form("mission_setup"):
        mode = st.radio("Data source", SOURCES, index=(3 if PERSON1_READY else 0),
                        help="Demo is not NASA data. Live mode uses JPL Horizons.")
        v2_method = st.radio("MM-01 V2 terrain model", list(V2_FILES), index=0,
                             help="Bilinear and nearest-pixel are different preliminary interpolation methods.")
        ids = st.multiselect("Candidate sites", options=list(by_id.keys()),
                             default=(["MM-01"] if PERSON1_READY else [x for x in by_id if x != "MM-01"][:3]),
                             format_func=lambda sid: f"{sid} · {by_id[sid].name}")
        custom = st.checkbox("Add/replace third site with custom coordinates")
        # Always render form fields. Conditional widgets cannot update until a
        # Streamlit form is submitted, causing an awkward second submission.
        lat = st.number_input("Custom latitude (°N; if selected)", -90.0, 90.0, -89.2, 0.1)
        lon = st.number_input("Custom east longitude (°; if selected)", -360.0, 360.0, 45.0, 1.0)
        alt = st.number_input("Custom altitude (km; if selected)", -20.0, 50.0,
                              0.0, 0.1)
        selected_date = st.date_input("Start date (UTC)", value=date(2026, 11, 14))
        second_date_on = st.checkbox("Compare with a second start date")
        second_date = st.date_input("Second start date (used if selected)",
                                    value=date(2026, 12, 14))
        days = st.slider("Window duration (days)", 1, 30, 7)
        step_minutes = st.select_slider("Sampling (minutes)",
                                         options=[15, 30, 60, 120, 180, 360], value=60)
        energy_weight = st.slider("Solar emphasis in relative score (%)", 0, 100, 50, 5)
        imported_file = st.file_uploader(
            "Observer data CSV (used for Import mode)", type=["csv"],
            help="Source unverified; see README.md for CSV format")
        skyline_file = st.file_uploader(
            "Optional terrain skyline CSV (source is NOT verified)", type=["csv"],
            help="site_id,az_deg,horizon_el_deg. Example in data/ is NOT real terrain.")
        submit = st.form_submit_button("🚀 Analyze mission windows", use_container_width=True)

if submit or "analysis_result" not in st.session_state:
    try:
        chosen = [by_id[i] for i in ids]
        if custom:
            chosen = chosen[:2]
            chosen.append(LunarSite("X", "Custom site", lat, lon, alt))
        if not 1 <= len(chosen) <= 3:
            raise ValueError("Select 1–3 sites. Custom site takes the last slot.")
        if mode == PERSON1_MODE:
            if not PERSON1_READY:
                raise ValueError("V2 data files are missing. Extract the complete project ZIP again.")
            if "MM-01" not in by_id:
                raise ValueError("MM-01 site record was not found in data/sites.csv.")
            chosen = [by_id["MM-01"]]
            local_ephemeris, local_skyline = V2_FILES[v2_method]
            skyline_profiles = load_skyline(local_skyline.read_bytes())
            imported_data = load_observations(local_ephemeris.read_bytes())
        else:
            skyline_profiles = load_skyline(skyline_file.getvalue()) if skyline_file else {}
            imported_data = load_observations(imported_file.getvalue()) if imported_file else {}
        start_dates = [selected_date]
        if second_date_on:
            if second_date == selected_date:
                raise ValueError("Choose a different date for the second scenario")
            start_dates.append(second_date)
        mode_for_pipeline = "Import CSV (unverified)" if mode == PERSON1_MODE else mode
        with st.spinner("Computing Sun/Earth visibility and terrain-corrected windows..."):
            runs = read_runs(chosen, start_dates, days, step_minutes,
                             mode_for_pipeline, energy_weight, skyline_profiles, imported_data)
        if mode == PERSON1_MODE:
            for run in runs:
                run["source"] = PERSON1_MODE + " / " + v2_method
                for frame in run["details"].values():
                    frame["source"] = PERSON1_MODE + " / " + v2_method
        st.session_state["analysis_result"] = (runs, skyline_profiles)
    except (ValueError, TerrainError, HorizonsError, KeyError, IndexError) as exc:
        st.error(f"Analysis stopped: {exc}")
        st.info("For a UI preview select SYNTHETIC demo. This app never substitutes "
                "invented values after a NASA request fails.")
        st.stop()

runs, profiles = st.session_state["analysis_result"]
source = runs[0]["source"]
if source == SOURCES[0]:
    st.error("🧪 **SYNTHETIC DEMO — ALL POSITIONS AND SCORES ARE ILLUSTRATIVE. "
             "NOT NASA DATA.** Switch to live Horizons for real ephemerides.")
elif source == SOURCES[1]:
    st.success("Source: NASA/JPL Horizons live query. Geometric angles are real "
               "ephemerides; the sites may still be illustrative.")
else:
    st.warning("Source: imported local CSV. Numerical values and provenance are "
               "**not independently verified**.")
if source.startswith(PERSON1_MODE):
    st.info("📂 Using 721 hourly NASA Horizons samples from the V2 handoff and the NASA LOLA-derived terrain skyline covering 360 azimuth directions. "
            "These observations must not be applied to sites other than MM-01.")
    st.warning("🔬 PRELIMINARY RESEARCH: The Horizons observer altitude in the V2 data is 6.4578076 km. "
               "However, the first 120 m from the observer was excluded from the horizon scan, and terrain beyond 50 km was not assessed. "
               "The modeled '721/721 Earth-center visibility' is NOT a communication guarantee. "
               "Visibility intervals are estimated by interpolation between samples; landing safety was not evaluated.")
    with st.expander("V2 data provenance and interpolation sensitivity", expanded=False):
        st.markdown("**Bilinear:** 459/721 Sun-center visible samples · **Nearest:** 450/721 · "
                    "The Earth center is visible in 721/721 samples in both models (not evidence of uninterrupted communications). "
                    "The models disagree on the Sun-center visibility flag at 9 timestamps. "
                    "Date range: November 14–December 14, 2026 UTC.")
        st.write(json.loads(LOCAL_SUMMARY.read_text(encoding="utf-8")))
if profiles and source.startswith(PERSON1_MODE):
    st.info("The MM-01 V2 terrain skyline is **loaded and included in the visibility model**. "
            "These are preliminary results: the first 120 m was not surveyed; "
            "DEM and Horizons elevation datums and model uncertainties "
            "require independent validation. Geometric Earth visibility does not guarantee a radio connection.")
elif profiles:
    st.warning("Terrain skyline correction is ON. Supplied skyline CSV provenance "
               "and geographic alignment were NOT independently verified. "
               "The included template skyline is entirely fabricated.")
else:
    st.info("No terrain skyline loaded — all results are relative to an **ideal 0° "
            "horizon**, which may overestimate lunar south-pole sunlight and Earth LOS.")

active = runs[0]
top = active["metrics"].iloc[0]
st.caption(f"Scenario 1: {active['start']:%Y-%m-%d} to {active['end']:%Y-%m-%d} UTC "
           f"· sample {active['step_minutes']} min · relative solar weighting "
           f"{active['energy_weight']}% · source: {source}")
a, b, c, d = st.columns(4)
a.metric("Analyzed site" if source.startswith(PERSON1_MODE) else "Top *relative* candidate", str(top["site_id"]))
b.metric("Sun visible (center)", f"{top['sunlight_pct']:.1f}%")
c.metric("Earth geometric LOS", f"{top['earth_los_pct']:.1f}%")
d.metric("Longest Earth outage", f"{top['longest_outage_h']:.1f} h")

st.subheader("🏁 MM-01 preliminary analysis" if source.startswith(PERSON1_MODE) else "🏁 Landing-site comparison")
selected_columns = {
    "site_id": "Site", "sunlight_h": "Sun above horizon (h)",
    "sunlight_pct": "Sun visible (%)", "earth_los_h": "Earth LOS (h)",
    "earth_los_pct": "Earth LOS (%)", "dual_visibility_h": "Both visible (h)",
    "longest_earth_window_h": "Longest link (h)",
    "longest_outage_h": "Longest outage (h)",
    "mean_solar_proxy": "Mean solar proxy (0–1)",
    "relative_solar_pct": "Solar relative index (%)",
    "relative_score_pct": "Heuristic score (%)",
}
comparison = active["metrics"][list(selected_columns)].rename(columns=selected_columns)
st.dataframe(comparison.round(3), use_container_width=True, hide_index=True)
st.caption("**Scoring is a subjective ranking**, not a flight readiness/safety certificate. "
           "Solar relative index is normalized against the sites in this comparison. "
           "Geometric Earth LOS does not guarantee a radio connection.")

fig = go.Figure()
for field, label, color in (
    ("sunlight_pct", "Sun visible (%)", "#F5C15D"),
    ("earth_los_pct", "Earth LOS (%)", "#77CEFF"),
    ("dual_visibility_pct", "Both (%)", "#60D29A"),
):
    fig.add_bar(x=active["metrics"].site_id, y=active["metrics"][field],
                name=label, marker_color=color)
fig.update_layout(barmode="group", yaxis_title="Percentage of scenario time",
                  xaxis_title="Candidate site", height=330, margin=dict(t=20, b=20))
st.plotly_chart(fig, use_container_width=True)

if len(runs) == 2:
    other = runs[1]
    st.subheader("📆 How does the start date change the outcome?")
    one = active["metrics"][["site_id", "sunlight_pct", "earth_los_pct", "relative_score_pct"]]
    two = other["metrics"][["site_id", "sunlight_pct", "earth_los_pct", "relative_score_pct"]]
    joined = one.merge(two, on="site_id", suffixes=("_date1", "_date2"))
    joined["score_delta_points"] = (
        joined["relative_score_pct_date2"] - joined["relative_score_pct_date1"]
    )
    st.dataframe(joined.round(2), use_container_width=True, hide_index=True)
    st.caption(f"Date 1 = {active['start']:%Y-%m-%d}; "
               f"Date 2 = {other['start']:%Y-%m-%d}. "
               "Scores are recalculated relative to the selected sites within each date.")

st.subheader("📡 Sun and Earth sky positions")
scenario_to_show = 0
if len(runs) > 1:
    scenario_to_show = st.radio("Choose scenario details", [0, 1],
                                format_func=lambda i: f"Start {runs[i]['start']:%Y-%m-%d}",
                                horizontal=True)
shown = runs[scenario_to_show]
tabs = st.tabs([f"{site.site_id} · {site.name}" for site in shown["sites"]])
for site, tab in zip(shown["sites"], tabs):
    with tab:
        frame = shown["details"][site.site_id]
        w = shown["windows"][site.site_id]
        st.caption(f"Coordinates: {site.latitude_deg:.3f}° N, "
                   f"{site.longitude_east_deg:.3f}° E, "
                   f"{site.altitude_km:.3f} km · {site.provenance}")
        left, right = st.columns([3, 2])
        with left:
            st.plotly_chart(create_line_figure(frame, site.site_id in profiles),
                            use_container_width=True)
        with right:
            st.plotly_chart(create_sky_figure(frame), use_container_width=True)
        st.caption("A positive elevation is above the local *ideal reference* horizon. "
                   "With a validated skyline, compare each body to its matching terrain-horizon curve. "
                   "Crossing times are interpolated, not exact events.")
        cols = st.columns(3)
        cols[0].metric("Sun-visible windows", len(w["Sun"]))
        cols[1].metric("Earth link windows", len(w["Earth LOS"]))
        cols[2].metric("Simultaneous windows", len(w["Both"]))
        st.dataframe(windows_table(w).round(3), use_container_width=True, hide_index=True)

if source.startswith(PERSON1_MODE):
    st.subheader("⛰️ MM-01 terrain skyline — 360 directions")
    the_profile = profiles.get("MM-01")
    if the_profile is not None:
        f_h = go.Figure()
        f_h.add_trace(go.Scatter(x=the_profile["az_deg"], y=the_profile["horizon_el_deg"],
                                 mode="lines", name="LOLA-derived terrain skyline", line={"color": "#C78DF0"}))
        f_h.add_hline(y=0, line_dash="dash", line_color="gray")
        f_h.update_layout(xaxis_title="Azimuth (°)", yaxis_title="Terrain horizon elevation (°)",
                          height=330, margin=dict(l=8,r=8,t=10,b=12))
        st.plotly_chart(f_h, use_container_width=True)
        st.caption("Model resolution: 1° azimuth step, 50 km survey radius; the first 120 m is excluded. Terrain line-of-sight is approximate.")
    with st.expander("📦 Download original V2 research files", expanded=False):
        for name in ("MM01_visibility_bilinear_v2.csv", "MM01_visibility_nearest_v2.csv",
                     "MM01_horizon_bilinear_v2.csv", "MM01_horizon_nearest_v2.csv",
                     "MM01_V2_ozet.json", "MM01_V2_science_handoff_EN.md"):
            file = ROOT / "data" / "MM01_V2_ON_ANALIZ" / name
            st.download_button(name, data=file.read_bytes(), file_name=name,
                               mime="application/json" if name.endswith(".json") else "text/plain")

st.subheader("⬇️ Reproducible output")
all_rows = pd.concat([frame for frame in active["details"].values()], ignore_index=True)
st.download_button("Download current comparison CSV",
                   active["metrics"].to_csv(index=False).encode("utf-8-sig"),
                   file_name="comparison.csv", mime="text/csv")
st.download_button("Download current ephemerides CSV",
                   all_rows.to_csv(index=False).encode("utf-8-sig"),
                   file_name="ephemerides.csv", mime="text/csv")
meta = {
    "team": "She'ar Force", "source": source,
    "start_utc": active["start"].isoformat(), "stop_utc": active["end"].isoformat(),
    "step_minutes": active["step_minutes"],
    "energy_weight_pct": active["energy_weight"],
    "skyline_uploaded": bool(profiles),
    "site_catalog": [{"id": s.site_id, "lat_deg": s.latitude_deg,
                      "lon_east_deg": s.longitude_east_deg, "altitude_km": s.altitude_km,
                      "provenance": s.provenance} for s in active["sites"]],
    "limitations": ["Body-center geometric visibility", "No radio link budget",
                    "Terrain model local V2 for MM-01 only; 120m near-field omitted; no cross-site generalization",
                    "No mission certification"],
}
st.download_button("Download analysis metadata JSON", json.dumps(meta, indent=2),
                   file_name="analysis_metadata.json", mime="application/json")
if len(runs) > 1:
    second = runs[1]
    st.download_button("Download second-date comparison CSV",
                       second["metrics"].to_csv(index=False).encode("utf-8-sig"),
                       file_name="comparison_second_date.csv", mime="text/csv")
    second_all = pd.concat(list(second["details"].values()), ignore_index=True)
    st.download_button("Download second-date ephemerides CSV",
                       second_all.to_csv(index=False).encode("utf-8-sig"),
                       file_name="ephemerides_second_date.csv", mime="text/csv")

with st.expander("🔬 Methodology · scientific assumptions · official sources"):
    st.markdown("""
    **NASA/JPL Horizons** provides airless apparent AZ/EL as seen from a lunar
    surface observer (`CENTER='coord@301'`, `QUANTITIES='4'`, Sun `10`, Earth `399`).
    [JPL API](https://ssd-api.jpl.nasa.gov/doc/horizons.html) ·
    [Horizons manual](https://ssd.jpl.nasa.gov/horizons/manual.html).

    **Visibility:** the body *center* must be above 0° (ideal) or above the
    azimuth-interpolated terrain skyline (uploaded CSV). Between samples,
    elevations/clearances are linearly interpolated. This can miss short
    events; repeat with a smaller step to assess sensitivity. Finite disc
    size, eclipses, physical radio effects and terrain outside the supplied
    skyline are excluded.

    **Energy proxy:** the time average of `max(0,sin(Sun elevation))` on a
    flat horizontal panel when not blocked by the skyline; dimensionless.
    It is **not** kWh, installed solar output, thermal safety or array sizing.

    **Score:** energy weighting × solar proxy normalized by the maximum
    among compared candidates + (1−weighting) × Earth visibility percent.
    Useful for scenario ranking, **not** evidence that landing is safe.

    **Terrain data references (not bundled):**
    [NASA Moon Trek](https://trek.nasa.gov/moon/) ·
    [LOLA PDS](https://imbrium.mit.edu/) ·
    [LROC QuickMap](https://quickmap.lroc.asu.edu/).
    The `data/terrain_profile_FORMAT_EXAMPLE.csv` has **invented** values
    and should *never* be presented as NASA DEM terrain data.

    NASA Space Apps 2026
    [official challenge](https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/).
    Independent project, not a NASA-certified tool or official NASA product.
    """)
