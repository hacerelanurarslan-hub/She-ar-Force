@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "data\MM01_import_for_streamlit.csv" (
  echo Required MM-01 data is missing. Extract the full archive again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>&1
  if not errorlevel 1 (
    py -m venv .venv
  ) else (
    python -m venv .venv
  )
)
if not exist ".venv\Scripts\python.exe" (
  echo Python virtual environment could not be created. Check your Python installation.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. Check the internet connection and Python version.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m streamlit run Mission_Control.py
pause
