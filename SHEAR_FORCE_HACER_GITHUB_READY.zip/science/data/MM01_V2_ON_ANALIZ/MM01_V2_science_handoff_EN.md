# MM-01 V2 Scientific Handoff (English)

Site: 85.4° S, 31.7° E. NASA-derived LOLA terrain elevation ~6.4578 km, 80 m raster. JPL Horizons samples from 2026-11-14 00:00 to 2026-12-14 00:00 UTC, at one-hour steps (721 timestamps).

**Caution**: First 120 m near field omitted, terrain scan truncated at 50 km. The reference datum and modeling precision require independent review. The 721/721 Earth-center sample result is NOT a guaranteed connection. See machine-readable V2 summary and included V2 CSV outputs.
