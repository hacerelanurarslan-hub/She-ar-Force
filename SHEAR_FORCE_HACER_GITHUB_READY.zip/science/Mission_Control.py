# Cinematic homepage / source data remain unchanged in the dedicated science pages.
# Rendered HTML is entirely self-contained, including the supplied 2,163 V3 records.
from pathlib import Path
import streamlit as st
import streamlit.components.v1 as components

st.set_page_config(page_title="SHE'AR FORCE | Lunar Mission Control", page_icon="🌙", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""<style>
header[data-testid="stHeader"]{background:transparent!important;height:0!important;}
[data-testid="stAppViewContainer"]{background:#040d19!important;}
[data-testid="stMainBlockContainer"],.block-container{max-width:none!important;padding:0!important;margin:0!important;}
[data-testid="stMain"]{padding:0!important;}
[data-testid="stVerticalBlock"]{gap:0!important;}
[data-testid="stSidebar"]{background:#0b2032!important;border-right:1px solid #24526b;}
iframe{display:block;}
</style>""",unsafe_allow_html=True)
with st.sidebar:
    st.markdown("### 🌙 SHE'AR FORCE")
    st.caption("CINEMATIC MISSION CONTROL / V3")
    st.page_link("pages/01_Three_Site_V3.py", label="📊 Three-site science lab")
    st.page_link("pages/02_MM01_V2.py", label="🌕 Legacy MM-01 V2")
    st.page_link("pages/00_Mission_Brief.py", label="📋 Mission brief")
    st.caption("Navigation, visualization and preliminary science. No NASA landing certification.")
html=(Path(__file__).resolve().parent/"Cinematic_Navigator.html").read_text(encoding="utf-8")
components.html(html,height=3500,scrolling=False)
