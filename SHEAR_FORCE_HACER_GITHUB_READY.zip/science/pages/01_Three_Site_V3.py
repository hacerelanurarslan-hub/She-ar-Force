# Team Member 1 V3: independent three-site comparison page
# AI-assisted implementation; original V2 untouched in separate app page.
from pathlib import Path
from datetime import date
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="She'ar Force | Three-Site V3",page_icon="🌕",layout="wide")
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "v3"

@st.cache_data(show_spinner=False)
def load_data():
    times = pd.read_csv(DATA / "uc_bolge_saatlik_2163_satir.csv", encoding="utf-8-sig")
    sites = pd.read_csv(DATA / "uc_bolge_metrikler.csv", encoding="utf-8-sig")
    method = pd.read_csv(DATA / "uc_bolge_yontem_karsilastirmasi.csv", encoding="utf-8-sig")
    times["time_utc"] = pd.to_datetime(times["time_utc"], utc=True)
    times["utc_date"] = times["time_utc"].dt.date
    return times, sites, method

T, S, M = load_data()
expected_sites = {"MM-01", "MMP-02", "NR-03"}
if len(T)!=2163 or set(T.site_id)!=expected_sites or not all((T.site_id==i).sum()==721 for i in expected_sites):
    st.error("V3 dataset is incomplete or does not match the documented 3 × 721 records.")
    st.stop()
if not (T["sun_center_unobstructed"].isin([0,1]).all()
        and T["earth_center_unobstructed"].isin([0,1]).all()):
    st.error("Unexpected visibility flags in dataset.")
    st.stop()

st.markdown("""<style>
[data-testid="stAppViewContainer"]{background:radial-gradient(ellipse at 88% 0%,rgba(34,112,147,.18),transparent 44%),#071323}
[data-testid="stSidebar"]{background:#0c1b30;border-right:1px solid #1c3b57}
.block-container{max-width:1380px;padding-top:1.8rem}
[data-testid="stMetric"]{background:#122940;border:1px solid #2b526a;border-radius:16px;padding:14px 17px}
[data-testid="stPlotlyChart"]{border:1px solid #203b52;border-radius:15px;background:#0c1c30;padding:8px}
.v3-banner{border:1px solid #2c6572;border-radius:22px;background:linear-gradient(117deg,#123853,#10243b 65%,#16465b);padding:20px 25px;margin-bottom:17px}
.v3-banner b{font-size:.75rem;letter-spacing:.20em;color:#73e5d5}
.v3-banner h2{color:#f2fcff;font-size:2.1rem;margin:5px 0}
.v3-banner small{color:#afcfdf}
</style>""",unsafe_allow_html=True)
st.markdown("""<div class="v3-banner"><b>SHE'AR FORCE / NAVIGATION LAB</b><h2>Three-Site Explorer</h2><small>Hourly NASA-derived V3 center visibility · research prototype</small></div>""",unsafe_allow_html=True)
st.page_link("Mission_Control.py",label="◉ BACK TO MISSION CONTROL",icon="🌘")
st.caption("SHE'AR FORCE · NASA SPACE APPS 2026 · EXPERIMENTAL RESEARCH PROTOTYPE")
st.subheader("Science view · three sites / 721 time snapshots each")
st.page_link("pages/00_Mission_Brief.py", label="✨ View the jury-friendly mission briefing", icon="📋")
st.write("**MM-01 • MMP-02 • NR-03** — Sun/Earth *center* visibility from the supplied NASA-derived, terrain-adjusted 20 m near / 80 m far DEM V3 preliminary data. Choose a site and UTC day to inspect recorded hourly samples.")
st.warning("PRELIMINARY MODEL — Not independently certified. Samples are not continuous illumination, guaranteed radio links, safe landing zones or NASA-approved sites. NR-03 Earth 0/721 is unverified. The original MM-01 V2 uses a different near-field exclusion and must not be silently compared as identical methodology.")

names = dict(zip(S.id, S.name))
with st.sidebar:
    st.header("🌕 V3 Three-Site Controls")
    site = st.selectbox("Sample site", sorted(names),format_func=lambda i:f"{i} · {names[i]}",key="v3_site")
    day = st.date_input("UTC day (24 samples)", value=date(2026,11,14),min_value=date(2026,11,14),max_value=date(2026,12,13),key="v3_day")
    st.caption("Date range: Nov 14–Dec 13 UTC for full 24-sample days; Dec 14 00:00 is the 721st endpoint.")

meta = S.set_index("id").loc[site]
rows=T[T.site_id==site].copy()
daily=rows[rows.utc_date==day].copy()
if len(daily)!=24:
    st.error("The selected UTC day does not have 24 observations; no extrapolation was performed.")
    st.stop()

st.subheader(f"{site} · {meta['name']}")
st.caption(f"Coordinates: {float(meta['latitude_deg']):.3f}° N, {float(meta['longitude_east_deg']):.3f}° E · 20 m DEM height: {float(meta['height20_bilinear_m']):.1f} m (model datum; not geodetic validation)")

scount=int(daily.sun_center_unobstructed.sum()); ecount=int(daily.earth_center_unobstructed.sum()); bcount=int(daily.both_centers_unobstructed.sum())
a,b,c=st.columns(3)
a.metric("☀️ Sun center visible · day", f"{scount}/24",f"{scount/24:.1%}")
b.metric("🌍 Earth center visible · day",f"{ecount}/24",f"{ecount/24:.1%}")
c.metric("☀️🌍 Both visible · day",f"{bcount}/24",f"{bcount/24:.1%}")

left,right = st.columns([3,2])
with left:
    st.subheader("Selected UTC day · angular clearance")
    fig = go.Figure()
    fig.add_hline(y=0,line_dash="dash",line_color="gray",annotation_text="Terrain horizon · 0° clearance")
    fig.add_trace(go.Scatter(x=daily.time_utc,y=daily.sun_clearance_deg,mode="lines+markers",name="Sun clearance",line=dict(color="#F5C15D",width=3)))
    fig.add_trace(go.Scatter(x=daily.time_utc,y=daily.earth_clearance_deg,mode="lines+markers",name="Earth clearance",line=dict(color="#77CEFF",width=3)))
    fig.update_layout(height=420,margin=dict(l=10,r=10,t=20,b=15),hovermode="x unified",xaxis_title="UTC",yaxis_title="Elevation minus directional terrain horizon (°)",legend=dict(orientation="h",y=1.15))
    st.plotly_chart(fig,use_container_width=True)
with right:
    st.subheader("30-day model sample comparison")
    totals=T.groupby("site_id",sort=False)[["sun_center_unobstructed","earth_center_unobstructed","both_centers_unobstructed"]].sum()
    totals=totals.loc[["MM-01","MMP-02","NR-03"]]
    fig2=go.Figure()
    for col,label,color in [
        ("sun_center_unobstructed","Sun center","#F5C15D"),
        ("earth_center_unobstructed","Earth center","#77CEFF"),
        ("both_centers_unobstructed","Both centers","#60D29A")]:
        fig2.add_bar(name=label,x=totals.index,y=totals[col]/721*100,marker_color=color)
    fig2.update_layout(barmode="group",height=420,margin=dict(l=0,r=0,t=20,b=15),yaxis=dict(title="Visible sample percentage",range=[0,105]),legend=dict(orientation="h",y=1.18))
    st.plotly_chart(fig2,use_container_width=True)

st.subheader("V3 bilinear totals · 721 hourly snapshots per site")
out = S[["id","name","latitude_deg","longitude_east_deg","sun_open_samples","earth_open_samples","both_open_samples","slope_20m_center_deg","slope_20m_neighborhood_max_deg"]].copy()
out["Sun %"]=(out.sun_open_samples/721*100).round(2)
out["Earth %"]=(out.earth_open_samples/721*100).round(2)
out["Both %"]=(out.both_open_samples/721*100).round(2)
st.dataframe(out[["id","name","Sun %","Earth %","Both %","sun_open_samples","earth_open_samples","both_open_samples","slope_20m_center_deg","slope_20m_neighborhood_max_deg"]].rename(columns={"id":"Site","name":"Name","sun_open_samples":"Sun samples","earth_open_samples":"Earth samples","both_open_samples":"Both samples","slope_20m_center_deg":"Center slope (°)","slope_20m_neighborhood_max_deg":"Max local slope (°)"}),use_container_width=True,hide_index=True)
st.caption("721 is the number of samples at 60-minute intervals from Nov 14 00:00 through Dec 14 00:00 UTC, endpoints included. Percentages are of sampled centers, not uninterrupted visibility hours.")

st.subheader("Nearest-pixel sensitivity · totals only")
st.caption("The separate teammate comparison export contains 6 summary rows. Nearest-pixel full hourly series was not supplied here: this section does not invent an hourly nearest-pixel time series.")
compact=M[["site","method","n_samples","sun_percent","earth_percent","both_percent"]].copy()
st.dataframe(compact.rename(columns={"site":"Site","method":"Method","n_samples":"Samples","sun_percent":"Sun %","earth_percent":"Earth %","both_percent":"Both %"}),hide_index=True,use_container_width=True)

with st.expander("Selected day · all 24 recorded hourly observations"):
    st.dataframe(daily[["time_utc","sun_azimuth_deg","sun_elevation_deg","sun_terrain_horizon_deg","sun_clearance_deg","sun_center_unobstructed","earth_azimuth_deg","earth_elevation_deg","earth_terrain_horizon_deg","earth_clearance_deg","earth_center_unobstructed","both_centers_unobstructed"]],use_container_width=True,hide_index=True)

a,b,c=st.columns(3)
with a:
    st.download_button("⬇️ Selected UTC day CSV",daily.drop(columns=["utc_date"]).to_csv(index=False).encode("utf-8-sig"),f"{site}_{day}_V3_bilinear.csv","text/csv")
with b:
    st.download_button("⬇️ This site's 721 samples",rows.drop(columns=["utc_date"]).to_csv(index=False).encode("utf-8-sig"),f"{site}_V3_721_bilinear.csv","text/csv")
with c:
    st.download_button("⬇️ All 2163 samples",(DATA/"uc_bolge_saatlik_2163_satir.csv").read_bytes(),"V3_all_three_sites_2163.csv","text/csv")

with st.expander("🔬 Methods, provenance, assumptions and version differences"):
    st.markdown("""
    - **Input:** teammate-supplied 3-site V3 modeled hourly records, derived from NASA JPL Horizons solar/Earth pointing and LOLA DEM elevations. This page **reads provided outputs**, not live Horizons requests. No independent validation of original DEM, site coordinates, Horizons settings or projection was performed here.
    - **V3:** 20 m near + 80 m far DEM, bilinear model with minimum 40 m near-field excluded (according to teammate documentation). The 20 m DEM cannot resolve lander-size rocks or local hazards.
    - **V2:** former MM-01-only, 80 m DEM, first 120 m omitted, different skyline model. A V2 vs V3 difference must not be framed as an experimental accuracy improvement without verification.
    - **Visibility:** 1 when the direction-specific modeled clearance of the relevant **body center** is positive. Finite Sun/Earth disc size, thermal cycles, Earth link budgets, eclipses and permanent shadowing are not fully assessed.
    - **NR-03 0/721 Earth:** suspicious or physically sensitive modeled finding; requires independent verification before claims.
    - **Landing-site eligibility:** no candidate-region boundary, slope-regolith safety, or actual descent/landing validation. These locations are research sample coordinates, **not certified landing sites**.
    - **Official resources:** [NASA Horizons API](https://ssd-api.jpl.nasa.gov/doc/horizons.html), [NASA Moon Trek](https://trek.nasa.gov/moon/), [NASA LOLA/PDS](https://imbrium.mit.edu/), [LROC QuickMap](https://quickmap.lroc.asu.edu/).
    - **AI disclosure:** Generated/edited with ChatGPT assistance; both teammates must review the code, results and evidence.
    """)
    st.write("Data file SHA-256:", __import__("hashlib").sha256((DATA/"uc_bolge_saatlik_2163_satir.csv").read_bytes()).hexdigest())

st.caption("V3 three-site page · research only · independent student team SHE'AR FORCE")
