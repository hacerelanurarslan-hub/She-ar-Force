# SHE'AR FORCE | Jury-friendly mission brief. AI-assisted UI; original analyses remain unchanged.
from pathlib import Path
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="She'ar Force | Mission Brief",page_icon="🌘",layout="wide")
ROOT=Path(__file__).resolve().parent.parent
DAT=ROOT/"data"/"v3"

@st.cache_data(show_spinner=False)
def load():
    t=pd.read_csv(DAT/"uc_bolge_saatlik_2163_satir.csv",encoding="utf-8-sig")
    s=pd.read_csv(DAT/"uc_bolge_metrikler.csv",encoding="utf-8-sig")
    m=pd.read_csv(DAT/"uc_bolge_yontem_karsilastirmasi.csv",encoding="utf-8-sig")
    t["time_utc"]=pd.to_datetime(t["time_utc"],utc=True)
    return t,s,m

T,S,M=load()
SITES=["MM-01","MMP-02","NR-03"]
if len(T)!=2163 or set(T.site_id)!=set(SITES) or any((T.site_id==i).sum()!=721 for i in SITES):
    st.error("Source data failed the 3 × 721 integrity check."); st.stop()
if any(int(T[T.site_id==r.id].sun_center_unobstructed.sum())!=int(r.sun_open_samples) for r in S.itertuples()):
    st.error("V3 source totals do not agree."); st.stop()

st.markdown("""<style>
.block-container{max-width:1280px;padding-top:1.8rem;padding-bottom:4rem}
.report-label{font-size:.72rem;letter-spacing:.24em;color:#73e2cb;font-weight:800;margin-bottom:8px}
.report-hero{border:1px solid #355d73;border-radius:20px;padding:34px;background:linear-gradient(115deg,#172d48,#0a1729 68%,#173d50)}
.report-hero h1{font-size:clamp(2.5rem,4.5vw,4.5rem);letter-spacing:-.055em;line-height:1.1;margin:10px 0 16px;color:#f6f9ff}
.report-hero p{font-size:1.08rem;color:#c5d5e8;max-width:900px;line-height:1.65}
.report-tag{display:inline-block;border:1px solid #568198;color:#9de9d8;padding:6px 12px;border-radius:30px;margin:5px 8px 0 0;font-size:.75rem}
.report-head{font-size:.8rem;font-weight:800;letter-spacing:.14em;color:#76dfc7;margin:28px 0 10px}
.report-insight{border-left:4px solid #63ddc1;background:#163444;padding:18px 20px;border-radius:4px 14px 14px 4px;color:#e3f7ff;line-height:1.6}
.report-caveat{background:#322d2a;border-left:4px solid #e8bf77;border-radius:5px 12px 12px 5px;padding:14px 18px;color:#f3e1ba}
</style>""",unsafe_allow_html=True)
st.markdown("""<div class="report-hero"><div class="report-label">SHE'AR FORCE / MISSION BRIEF 2026</div>
<h1>Where should we<br><span style="color:#67dfc1">land next?</span> 🌕</h1>
<p>From NASA-derived terrain and directional ephemerides to a clearer, uncertainty-aware comparison of three lunar South Pole research locations.</p>
<span class="report-tag">03 SAMPLE SITES</span><span class="report-tag">2,163 HOURLY RECORDS</span><span class="report-tag">20 m NEAR / 80 m FAR DEM</span><span class="report-tag">V3 BILINEAR · RESEARCH ONLY</span></div>""",unsafe_allow_html=True)

st.markdown('<div class="report-head">01 / EXECUTIVE FINDING</div>',unsafe_allow_html=True)
st.markdown("""<div class="report-insight"><b>MM-01 · Mons Mouton leads this limited three-site sample</b> on modeled Sun, Earth and simultaneous <i>center</i> visibility. This is a preliminary dataset comparison, not a certified safest or optimal landing-site recommendation.</div>""",unsafe_allow_html=True)
cols=st.columns(4)
for col,value,label in zip(cols,["3","721","53.81%","95.70%"],["Sample locations","Snapshots per site","MM-01 both centers · V3","MM-01 Earth center · V3"]):
    with col: st.metric(label,value)

st.markdown('<div class="report-head">02 / COMPARISON · V3 BILINEAR</div>',unsafe_allow_html=True)
labels=dict(zip(S.id,S.name))
totals=T.groupby("site_id")[["sun_center_unobstructed","earth_center_unobstructed","both_centers_unobstructed"]].sum().loc[SITES].div(721).mul(100)
c1,c2=st.columns([1.8,1])
with c1:
    fig=go.Figure()
    for col,label,color in [("sun_center_unobstructed","Sun center","#f7c46b"),("earth_center_unobstructed","Earth center","#80caff"),("both_centers_unobstructed","Both centers","#67dfc1")]:
        fig.add_trace(go.Bar(name=label,y=[labels.get(i,i) for i in SITES],x=totals[col].round(2),orientation="h",marker_color=color,text=totals[col].map(lambda v:f"{v:.1f}%"),textposition="outside",cliponaxis=False))
    fig.update_layout(barmode="group",height=360,margin=dict(l=0,r=70,t=20,b=10),xaxis=dict(range=[0,112],title="Percent of 721 snapshots",gridcolor="#31455f"),yaxis=dict(autorange="reversed"),legend=dict(orientation="h",y=1.19),paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",font=dict(color="#e6eef8"))
    st.plotly_chart(fig,use_container_width=True)
with c2:
    st.markdown("#### Why this matters")
    st.write("Solar line-of-sight is a potential power planning constraint. Earth line-of-sight is a prerequisite for direct communication geometry, **not** proof of a working link. Good percentages alone do not certify landing safety.")
    st.markdown("**Model scope**")
    st.caption("3 research coordinates · 14 Nov to 14 Dec 2026 UTC · 721 time snapshots / site · body centers only")

st.markdown('<div class="report-head">03 / 30-DAY TEMPORAL PATTERN</div>',unsafe_allow_html=True)
t=T[T.time_utc < pd.Timestamp("2026-12-14T00:00:00Z")].copy()
t["day"]=t.time_utc.dt.strftime("%b %d")
heat=t.groupby(["site_id","day"],sort=False)["both_centers_unobstructed"].sum().unstack("day").reindex(SITES)
if heat.shape!=(3,30):
    st.error("Daily 30-day source counts are incomplete.");st.stop()
fig=go.Figure(data=go.Heatmap(z=heat.values,x=list(heat.columns),y=[labels.get(i,i) for i in SITES],zmin=0,zmax=24,colorscale=[[0,'#182739'],[0.5,'#287e80'],[1,'#6bdfbe']],colorbar=dict(title="of 24"),hovertemplate="%{y}<br>%{x}: %{z}/24 hourly snapshots<extra></extra>"))
fig.update_layout(height=230,margin=dict(l=0,r=0,t=8,b=0),xaxis=dict(tickangle=-45,nticks=12),yaxis=dict(autorange="reversed"),paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",font=dict(color="#e6eef8"))
st.plotly_chart(fig,use_container_width=True)
st.caption("30 complete days only: daily cells show positive sampled center counts. The 721st Dec 14 00:00 endpoint is omitted from the heatmap; all 721 samples remain in the totals.")

st.markdown('<div class="report-head">04 / MODEL TRANSPARENCY</div>',unsafe_allow_html=True)
view=S[["id","name","sun_open_samples","earth_open_samples","both_open_samples","slope_20m_center_deg","slope_20m_neighborhood_max_deg"]].copy()
view.columns=["Site","Region","Sun /721","Earth /721","Both /721","Center slope (°)","Local max slope (°)"]
st.dataframe(view,hide_index=True,use_container_width=True)
with st.expander("Bilinear vs nearest-pixel · V3 summary sensitivity"):
    st.dataframe(M[["site","method","sun_percent","earth_percent","both_percent"]],hide_index=True,use_container_width=True)
    st.caption("Nearest-pixel V3 hourly time series was not provided in this package. Comparisons are summaries only.")

st.markdown('<div class="report-head">05 / LIMITATIONS & NEXT STEPS</div>',unsafe_allow_html=True)
c1,c2=st.columns(2)
with c1:
    st.markdown('<div class="report-caveat"><b>Scientific caution</b><br>NR-03 Earth 0/721 is not independently verified. Elevation reference, near-field omission, finite-disc treatment, and DEM resolution can change results. Sampled center visibility is not continuous sunlight, guaranteed radio link, or a landing certification.</div>',unsafe_allow_html=True)
with c2:
    st.markdown("**Engineering validation roadmap**")
    st.markdown("- Reproduce Horizons/LOLA geometry with independently checked observer heights.\n- Evaluate local landing hazards, slopes, and candidate-region boundaries.\n- Expand to configurable dates and sites with continuous-interval and link-budget analysis.")
with st.expander("NASA sources, V2/V3 differences and AI disclosure"):
    st.markdown("""**Data:** Teammate-supplied V3 20 m near / 80 m far, 40 m near-field exclusion (documented); NASA JPL Horizons ephemerides and LOLA elevation models. The older MM-01 V2 used an 80 m DEM with a 120 m near-field exclusion. Do not compare them as controlled identical models.\n\n**Resources:** [JPL Horizons](https://ssd-api.jpl.nasa.gov/doc/horizons.html) · [NASA Moon Trek](https://trek.nasa.gov/moon/) · [LOLA](https://imbrium.mit.edu/) · [Challenge](https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/)\n\n**Authorship:** Independent student team SHE'AR FORCE. Coding and communication received ChatGPT assistance; source results require team validation. No NASA endorsement is claimed.""")

st.markdown('<div class="report-head">06 / EXPLORE & TAKE AWAY</div>',unsafe_allow_html=True)
left,right=st.columns(2)
with left:
    st.page_link("pages/01_Three_Site_V3.py",label="🔬 Open interactive three-site analysis",icon="🌕")
with right:
    st.page_link("pages/02_MM01_V2.py",label="🧭 Open MM-01 V2 research analysis",icon="🌙")
html_report=(ROOT/"ShearForce_Jury_Mission_Report.html")
if html_report.exists():
    st.download_button("⬇️ Download the jury mission report (offline HTML / print to PDF)",html_report.read_bytes(),file_name="ShearForce_Jury_Mission_Report.html",mime="text/html",use_container_width=True)
st.caption("SHE'AR FORCE · NASA Space Apps Challenge 2026 · Research prototype · Not mission certified")
