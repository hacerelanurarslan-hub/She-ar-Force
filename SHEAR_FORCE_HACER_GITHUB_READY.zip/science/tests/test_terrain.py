import unittest
import numpy as np
from lunar_nav.terrain import load_skyline, horizon_at_azimuth, TerrainError

CSV = b"site_id,az_deg,horizon_el_deg\nA,10,6\nA,350,4\nB,90,1\nB,270,3\n"


class TerrainTests(unittest.TestCase):
    def test_wraparound_interpolation(self):
        skyline = load_skyline(CSV)["A"]
        self.assertAlmostEqual(horizon_at_azimuth(np.array([0.0]), skyline)[0], 5.0)
        self.assertAlmostEqual(horizon_at_azimuth(np.array([360.0]), skyline)[0], 5.0)

    def test_zero_profile_when_absent(self):
        result = horizon_at_azimuth(np.array([0.0, 180.0]), None)
        np.testing.assert_array_equal(result, [0, 0])

    def test_validates_duplicate_direction(self):
        with self.assertRaises(TerrainError):
            load_skyline(b"site_id,az_deg,horizon_el_deg\nA,0,1\nA,360,2\n")

    def test_rejects_missing_column(self):
        with self.assertRaises(TerrainError):
            load_skyline(b"site_id,az_deg\nA,0\nA,180\n")

    def test_rejects_empty(self):
        with self.assertRaises(TerrainError):
            load_skyline(b"site_id,az_deg,horizon_el_deg\n")

if __name__ == "__main__":
    unittest.main()
