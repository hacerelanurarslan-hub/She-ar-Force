"""Headless smoke test of entire Streamlit app via a minimal UI stub.

This tests Python control flow and Plotly figure serialization, NOT rendering
in a real browser. Actual Streamlit browser QA is documented as outstanding.
"""
import importlib.util
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch
import plotly.io as pio

ROOT = Path(__file__).resolve().parents[1]


class StubPanel:
    def __init__(self, fake):
        self.fake = fake

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return None

    def metric(self, *args, **kwargs):
        self.fake.metrics += 1

    def plotly_chart(self, fig, **kwargs):
        self.fake.plotly_chart(fig, **kwargs)


class FakeSt(types.ModuleType):
    def __init__(self):
        super().__init__("streamlit")
        self.session_state = {}
        self.sidebar = self
        self.metrics = 0
        self.figures = 0
        self.downloads = 0

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return None

    def cache_data(self, *args, **kwargs):
        return lambda func: func

    def form(self, *args, **kwargs):
        return self

    def spinner(self, *args, **kwargs):
        return self

    def expander(self, *args, **kwargs):
        return self

    def radio(self, label, options, index=0, **kwargs):
        return options[index]

    def selectbox(self, label, options, **kwargs):
        return options[0]

    def multiselect(self, label, options, default=None, **kwargs):
        return default

    def checkbox(self, *args, **kwargs):
        return False

    def number_input(self, label, min_value=None, max_value=None, value=None, step=None):
        return value

    def date_input(self, label, value=None, **kwargs):
        return value

    def slider(self, label, min_value=None, max_value=None, value=None, *args, **kwargs):
        return value

    def select_slider(self, label, options=None, value=None, **kwargs):
        return value

    def file_uploader(self, *args, **kwargs):
        return None

    def form_submit_button(self, *args, **kwargs):
        return False

    def columns(self, n, **kwargs):
        if isinstance(n, list):
            n = len(n)
        return [StubPanel(self) for _ in range(n)]

    def tabs(self, labels):
        return [StubPanel(self) for _ in labels]

    def metric(self, *args, **kwargs):
        self.metrics += 1

    def plotly_chart(self, fig, **kwargs):
        pio.to_json(fig, validate=True)
        self.figures += 1

    def download_button(self, label, data, **kwargs):
        self.downloads += 1
        assert data

    def stop(self):
        raise RuntimeError("App unexpectedly stopped")

    def __getattr__(self, name):
        if name in {"set_page_config", "caption", "title", "write", "header",
                    "error", "success", "warning", "info", "subheader",
                    "dataframe", "markdown", "page_link", "divider"}:
            return lambda *args, **kwargs: None
        raise AttributeError(f"Unexpected Streamlit API call: {name}")


class AppSmokeTests(unittest.TestCase):
    def test_complete_app_runs_offline_in_ui_stub(self):
        fake = FakeSt()
        file = ROOT / "app.py"
        namespace = {"__name__": "__lunar_test__", "__file__": str(file)}
        with patch.dict(sys.modules, {"streamlit": fake}):
            exec(compile(file.read_text(encoding="utf-8"), str(file), "exec"), namespace)
        self.assertEqual(len(fake.session_state["analysis_result"][0]), 1)
        self.assertGreaterEqual(fake.figures, 3 if (ROOT / "data" / "MM01_import_for_streamlit.csv").is_file() else 7)
        # MM-01 local import has one site; initial synthetic demo has three.
        self.assertGreaterEqual(fake.metrics, 7 if (ROOT / "data" / "MM01_import_for_streamlit.csv").is_file() else 13)
        self.assertGreaterEqual(fake.downloads, 3)

    def test_mission_control_page_data_and_charts(self):
        fake = FakeSt()
        file = ROOT / "Mission_Control.py"
        namespace = {"__name__": "__lunar_mission_control_test__", "__file__": str(file)}
        with patch.dict(sys.modules, {"streamlit": fake}):
            exec(compile(file.read_text(encoding="utf-8"), str(file), "exec"), namespace)
        self.assertGreaterEqual(fake.figures, 3)
        self.assertGreaterEqual(fake.metrics, 7)
        self.assertGreaterEqual(fake.downloads, 2)

    def test_legacy_v2_page_is_still_runnable(self):
        fake = FakeSt()
        file = ROOT / "pages" / "02_MM01_V2.py"
        namespace = {"__name__": "__lunar_v2_page_test__", "__file__": str(file)}
        with patch.dict(sys.modules, {"streamlit": fake}):
            exec(compile(file.read_text(encoding="utf-8"), str(file), "exec"), namespace)
        self.assertGreaterEqual(fake.figures, 3)
        self.assertGreaterEqual(fake.downloads, 3)

if __name__ == "__main__":
    unittest.main()
