import unittest
import pandas as pd

from lunar_nav.science import (
    add_clearance, duration_h, intersect_windows, outage_windows,
    rank_sites, summarize_site, visibility_windows,
)


def frame(sun, earth, sun_az=None, earth_az=None):
    n = len(sun)
    return pd.DataFrame({
        "timestamp_utc": pd.date_range("2026-11-14T00:00:00Z", periods=n, freq="h"),
        "sun_az_deg": sun_az or [0]*n,
        "sun_el_deg": sun,
        "earth_az_deg": earth_az or [180]*n,
        "earth_el_deg": earth,
    })


class ScienceTests(unittest.TestCase):
    def test_half_interval_crossing(self):
        stats, data, windows = summarize_site(frame([-10, 10, -10], [10, 10, 10]))
        self.assertAlmostEqual(stats["duration_h"], 2)
        self.assertAlmostEqual(stats["sunlight_h"], 1)
        self.assertAlmostEqual(stats["sunlight_pct"], 50)
        self.assertAlmostEqual(stats["earth_los_pct"], 100)
        self.assertAlmostEqual(stats["dual_visibility_h"], 1)
        self.assertEqual(len(windows["Sun"]), 1)
        self.assertAlmostEqual(stats["mean_solar_proxy"], 0.043412, places=4)

    def test_earth_outages(self):
        stats, _, w = summarize_site(frame([1,1,1], [-2, 2, -2]))
        self.assertAlmostEqual(stats["earth_los_h"], 1)
        self.assertAlmostEqual(stats["longest_outage_h"], 0.5)
        self.assertAlmostEqual(stats["longest_earth_window_h"], 1)
        self.assertEqual(len(w["Earth outage"]), 2)

    def test_all_below_horizon(self):
        stats, _, _ = summarize_site(frame([-1, -1], [-2, -2]))
        self.assertEqual(stats["sunlight_pct"], 0)
        self.assertEqual(stats["mean_solar_proxy"], 0)
        self.assertEqual(stats["earth_los_pct"], 0)

    def test_all_above_horizon(self):
        stats, _, _ = summarize_site(frame([10, 10], [20, 20]))
        self.assertEqual(stats["sunlight_pct"], 100)
        self.assertEqual(stats["earth_los_pct"], 100)
        self.assertAlmostEqual(stats["mean_solar_proxy"], 0.17364817766693)

    def test_skyline_blocks_sun_not_earth(self):
        horizon = pd.DataFrame({"az_deg": [0, 180], "horizon_el_deg": [5, 0]})
        stats, data, _ = summarize_site(frame([2, 2], [1, 1]), horizon)
        self.assertEqual(stats["sunlight_pct"], 0)
        self.assertEqual(stats["earth_los_pct"], 100)
        self.assertEqual(stats["mean_solar_proxy"], 0)
        self.assertTrue(stats["terrain_profile_applied"])

    def test_terrain_delays_rise(self):
        horizon = pd.DataFrame({"az_deg": [0, 180], "horizon_el_deg": [5, 0]})
        stats, _, _ = summarize_site(frame([0, 10], [8, 8]), horizon)
        self.assertAlmostEqual(stats["sunlight_h"], 0.5)
        self.assertGreater(stats["mean_solar_proxy"], 0)

    def test_both_overlap(self):
        stats, _, _ = summarize_site(frame([-10, 10, 10], [10, -10, 10]))
        self.assertAlmostEqual(stats["dual_visibility_h"], 0.5)

    def test_outage_when_never_visible(self):
        stats, _, outages = summarize_site(frame([1, 1], [-5, -5]))
        self.assertAlmostEqual(stats["longest_outage_h"], 1)
        self.assertEqual(len(outages["Earth outage"]), 1)

    def test_rank_weight_100_energy(self):
        scores = pd.DataFrame([
            {"site_id": "A", "mean_solar_proxy": 0.1, "earth_los_pct": 90},
            {"site_id": "B", "mean_solar_proxy": 0.2, "earth_los_pct": 10},
        ])
        result = rank_sites(scores, 100)
        self.assertEqual(result.iloc[0].site_id, "B")
        self.assertAlmostEqual(result.iloc[0].relative_score_pct, 100)

    def test_rank_weight_zero_comms(self):
        scores = pd.DataFrame([
            {"site_id": "A", "mean_solar_proxy": 0.1, "earth_los_pct": 90},
            {"site_id": "B", "mean_solar_proxy": 0.2, "earth_los_pct": 10},
        ])
        self.assertEqual(rank_sites(scores, 0).iloc[0].site_id, "A")

    def test_no_negative_or_over_100_pct(self):
        stats, _, _ = summarize_site(frame([0, 0, 0], [0, 0, 0]))
        self.assertGreaterEqual(stats["sunlight_pct"], 0)
        self.assertLessEqual(stats["earth_los_pct"], 100)

    def test_reject_duplicate_time(self):
        df = frame([1,2], [1,2])
        df.loc[1, "timestamp_utc"] = df.loc[0, "timestamp_utc"]
        with self.assertRaises(ValueError):
            summarize_site(df)

    def test_reject_out_of_bounds(self):
        with self.assertRaises(ValueError):
            summarize_site(frame([95, 1], [1, 2]))

if __name__ == "__main__":
    unittest.main()
