"""V2 research source controls, signed lunar longitude and terrain file helpers."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

import pandas as pd
from lunar_nav.sites import load_sites
from lunar_nav.horizons import query_params
from lunar_nav.download_dem import download, DemDownloadError, DEM_URLS
from lunar_nav.combine_skylines import combine
from datetime import datetime, timezone, timedelta

ROOT = Path(__file__).resolve().parents[1]


class SourceProvenanceTests(unittest.TestCase):
    def test_three_published_candidate_coordinate_values(self):
        actual = load_sites(ROOT / 'data' / 'sites.csv')
        self.assertEqual([s.site_id for s in actual[:3]], ['001','007','011'])
        self.assertEqual(actual[-1].site_id, 'MM-01')
        self.assertEqual((actual[-1].latitude_deg, actual[-1].longitude_east_deg), (-85.4, 31.7))
        expected = {
            '001': (-89.466, -136.949),
            '007': (-88.811, 123.554),
            '011': (-88.674, -68.228),
        }
        for site in actual[:3]:
            self.assertEqual((site.latitude_deg, site.longitude_east_deg), expected[site.site_id])
            self.assertIn('10.1029/2025JE009434',site.provenance)
            self.assertEqual(site.altitude_km,0.0) # Explicit approximation

    def test_jpl_signed_longitudes_converted_to_positive_east(self):
        sites=load_sites(ROOT / 'data/sites.csv')
        start=datetime(2026,11,14,tzinfo=timezone.utc)
        stop=start+timedelta(days=1)
        got={s.site_id:query_params('10',s,start,stop,60)['SITE_COORD'] for s in sites}
        self.assertEqual(got['001'],"'223.05100000,-89.46600000,0.000000'")
        self.assertEqual(got['007'],"'123.55400000,-88.81100000,0.000000'")
        self.assertEqual(got['011'],"'291.77200000,-88.67400000,0.000000'")

    def test_dem_links_exactly_match_published_site_mappings(self):
        for sid,sitenum in [('001','01'),('007','07'),('011','11')]:
            self.assertEqual(DEM_URLS[sid],
                f'https://pgda.gsfc.nasa.gov/data/LOLA_5mpp/Site{sitenum}/Site{sitenum}_final_adj_5mpp_surf.tif')

    def test_downloader_rejects_html_without_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            response=Mock()
            response.__enter__=Mock(return_value=response)
            response.__exit__=Mock(return_value=False)
            response.headers={'Content-Type':'text/html'}
            response.raise_for_status=Mock()
            session=Mock(get=Mock(return_value=response))
            with self.assertRaises(DemDownloadError):
                download('001',Path(tmp),session)
            self.assertEqual(list(Path(tmp).iterdir()),[])

    def test_downloader_saves_sha256_and_provenance_with_valid_signature(self):
        with tempfile.TemporaryDirectory() as tmp:
            response=Mock()
            response.__enter__=Mock(return_value=response)
            response.__exit__=Mock(return_value=False)
            response.headers={'Content-Type':'image/tiff'}
            response.raise_for_status=Mock()
            response.iter_content=Mock(return_value=iter([b'II*\x00'+b'\x01'*1100]))
            session=Mock(get=Mock(return_value=response))
            dest,meta=download('007',Path(tmp),session)
            self.assertTrue(dest.is_file())
            record=json.loads(meta.read_text())
            self.assertEqual(record['size_bytes'],1104)
            self.assertEqual(len(record['sha256']),64)
            self.assertIn('UNVALIDATED',record['scientific_status'])

    def test_rejects_invalid_site_dem_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                download('A',Path(tmp))

    def test_combine_multiple_skyline_csvs(self):
        with tempfile.TemporaryDirectory() as tmp:
            temp=Path(tmp)
            paths=[]
            for sid in ('001','007','011'):
                path=temp/f'{sid}.csv'
                pd.DataFrame({'site_id':[sid,sid],'az_deg':[0,180],
                              'horizon_el_deg':[1,2]}).to_csv(path,index=False)
                paths.append(path)
            result=combine(paths,temp/'out.csv')
            self.assertEqual(len(result),6)
            self.assertEqual(set(result['site_id']),{'001','007','011'})

    def test_rejects_duplicate_skyline_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            temp=Path(tmp)
            path=temp/'001.csv'
            pd.DataFrame({'site_id':['001','001'],'az_deg':[0,180],
                          'horizon_el_deg':[1,2]}).to_csv(path,index=False)
            with self.assertRaises(ValueError):
                combine([path,path],temp/'out.csv')


if __name__ == '__main__':
    unittest.main()
