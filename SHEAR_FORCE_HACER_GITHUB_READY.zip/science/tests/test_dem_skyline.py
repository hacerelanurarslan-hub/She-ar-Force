import tempfile
import unittest
from pathlib import Path
from math import isfinite
import numpy as np

from lunar_nav.dem_skyline import (
    DemSkylineError, destination, elevation_to_target, extract_skyline,
)


class DemTests(unittest.TestCase):
    def test_destination_north_from_pole(self):
        lat, lon = destination(-90, 0, 0, 17374)
        self.assertAlmostEqual(lat, -89.426, delta=0.01)
        self.assertAlmostEqual(lon, 0.0, places=5)

    def test_spherical_curvature_blocks_same_height_at_distance(self):
        angle = elevation_to_target(10000, 0, 0, 0)
        self.assertLess(angle, 0)
        self.assertAlmostEqual(angle, -0.1649, delta=0.002)

    def test_high_ridge_rises_above_horizon(self):
        angle = elevation_to_target(1000, 0, 100, 0)
        self.assertGreater(angle, 5)

    def test_bad_coordinates_rejected(self):
        with self.assertRaises(DemSkylineError):
            extract_skyline("nowhere.tif", "A", -91, 0)

    def test_end_to_end_mock_lunar_geotiff(self):
        try:
            import rasterio
            from rasterio.transform import from_origin
            from rasterio.crs import CRS
        except ImportError:
            self.skipTest("Optional DEM dependencies not installed")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "synthetic_lunar_dem.tif"
            radius = 1737400
            crs = CRS.from_proj4(
                "+proj=stere +lat_0=-90 +lon_0=0 +k=1 +a=1737400 "
                "+b=1737400 +units=m +no_defs")
            transform = from_origin(-10000, 10000, 100, 100)
            arr = np.zeros((200, 200), dtype=np.float32)
            # Artificial ridge 1 km north of the pole, purely test data.
            arr[85:90, 90:110] = 200
            with rasterio.open(path, "w", driver="GTiff", width=200,
                                height=200, count=1, dtype="float32",
                                transform=transform, crs=crs, nodata=-9999) as dst:
                dst.write(arr, 1)
            result = extract_skyline(path, "A", -90, 0, range_km=5,
                                     step_m=200, az_step_deg=30, mast_height_m=1.5)
            self.assertEqual(len(result), 12)
            self.assertTrue(np.isfinite(result.horizon_el_deg).all())
            self.assertTrue((result.az_deg >= 0).all())

if __name__ == "__main__":
    unittest.main()
