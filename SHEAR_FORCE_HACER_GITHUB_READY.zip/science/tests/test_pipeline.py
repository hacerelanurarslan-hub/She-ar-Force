import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pandas as pd

from lunar_nav.pipeline import run_scenario
from lunar_nav.sites import load_sites, LunarSite
from lunar_nav.demo import synthetic_site
from lunar_nav.io import load_observations
from lunar_nav.horizons import HorizonsError

ROOT = Path(__file__).resolve().parents[1]
START = datetime(2026, 11, 14, tzinfo=timezone.utc)
SITES = [site for site in load_sites(ROOT / "data/sites.csv") if site.site_id in ("001", "007", "011")]


class PipelineTests(unittest.TestCase):
    def test_full_3_site_7_day_pipeline(self):
        result = run_scenario(SITES, START, 7, 60, "SYNTHETIC demo (offline)", 50)
        self.assertEqual(len(result["metrics"]), 3)
        self.assertEqual(len(result["details"]), 3)
        for data in result["details"].values():
            self.assertEqual(len(data), 169)
            self.assertTrue(data.source.str.contains("SYNTHETIC").all())
            self.assertTrue(data.timestamp_utc.dt.tz is not None)
        self.assertTrue(result["metrics"]["relative_score_pct"].between(0, 100).all())

    def test_30_day_15_min_grid(self):
        result = run_scenario(SITES[:1], START, 30, 15,
                              "SYNTHETIC demo (offline)", 50)
        self.assertEqual(len(result["details"][SITES[0].site_id]), 2881)

    def test_synthetic_round_trip_requires_provenance_label(self):
        result = run_scenario(SITES[:1], START, 1, 60,
                              "SYNTHETIC demo (offline)", 50)
        csv = result["details"][SITES[0].site_id].to_csv(index=False).encode()
        imported = load_observations(csv)
        self.assertEqual(imported[SITES[0].site_id].iloc[0].source,
                         "IMPORTED CSV — provenance unverified")
        rerun = run_scenario(SITES[:1], START, 1, 60,
                             "Import CSV (unverified)", 50, imports=imported)
        self.assertEqual(rerun["metrics"].iloc[0].site_id, SITES[0].site_id)

    def test_partial_csv_rejected_not_optimistically_scaled(self):
        df = synthetic_site(SITES[0], START, START + timedelta(hours=1), 60)
        imported = load_observations(df.to_csv(index=False).encode())
        with self.assertRaisesRegex(ValueError, "complete requested time grid"):
            run_scenario(SITES[:1], START, 1, 60,
                         "Import CSV (unverified)", 50, imports=imported)

    def test_real_mode_failure_does_not_fallback(self):
        def fake_fail(*args):
            raise HorizonsError("no network")
        with self.assertRaisesRegex(HorizonsError, "no network"):
            run_scenario(SITES[:1], START, 1, 60,
                         "NASA/JPL Horizons (live)", 50, fetch_fn=fake_fail)

    def test_mock_real_nasa_pipeline(self):
        def fake_response(site, start, stop, step):
            df = synthetic_site(site, start, stop, step)
            df["source"] = "TEST FIXTURE MOCK (not NASA)"
            return df
        result = run_scenario(SITES[:3], START, 1, 60,
                              "NASA/JPL Horizons (live)", 50,
                              fetch_fn=fake_response)
        self.assertEqual(len(result["metrics"]), 3)
        self.assertTrue(result["details"][SITES[0].site_id].source.str.contains("MOCK").all())

    def test_invalid_site_count(self):
        with self.assertRaises(ValueError):
            run_scenario([], START, 1, 60, "SYNTHETIC demo (offline)", 50)

    def test_invalid_day(self):
        with self.assertRaises(ValueError):
            run_scenario(SITES[:1], START, 31, 60, "SYNTHETIC demo (offline)", 50)

    def test_site_coordinates_validated(self):
        with self.assertRaises(ValueError):
            LunarSite("Q", "Invalid", -100.0, 0)

    def test_imported_data_keeps_utc(self):
        df = synthetic_site(SITES[0], START, START + timedelta(days=1), 60)
        data = load_observations(df.to_csv(index=False).encode())
        self.assertEqual(data[SITES[0].site_id].timestamp_utc.iloc[0], pd.Timestamp(START))

if __name__ == "__main__":
    unittest.main()
