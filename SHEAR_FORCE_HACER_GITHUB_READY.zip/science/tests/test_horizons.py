import unittest
from unittest.mock import Mock, patch
from datetime import datetime, timedelta, timezone
from requests.exceptions import ConnectionError

from lunar_nav.horizons import (
    HorizonsError, fetch_body, fetch_site, parse_horizons_csv, query_params,
)
from lunar_nav.sites import LunarSite

SITE = LunarSite("A", "Test site", -89.5, 15.0)
START = datetime(2026, 11, 14, 0, 0, tzinfo=timezone.utc)
STOP = START + timedelta(hours=1)
CSV = """Date__(UT)__HR:MN, Obs, Azi_(a-app), Elev_(a-app),
$$SOE
 2026-Nov-14 00:00, * , 120.000001, 1.000001,
 2026-Nov-14 01:00, A , 121.000001, -2.500001,
$$EOE
"""


class HorizonsTests(unittest.TestCase):
    def test_parameter_values_match_official_docs(self):
        p = query_params("10", SITE, START, STOP, 60)
        self.assertEqual(p["COMMAND"], "'10'")
        self.assertEqual(p["CENTER"], "'coord@301'")
        self.assertEqual(p["QUANTITIES"], "'4'")
        self.assertEqual(p["SITE_COORD"], "'15.00000000,-89.50000000,0.000000'")
        self.assertEqual(p["CSV_FORMAT"], "'YES'")

    def test_parser_handles_presence_markers(self):
        frame = parse_horizons_csv(CSV)
        self.assertEqual(len(frame), 2)
        self.assertAlmostEqual(frame.iloc[0].az_deg, 120.000001)
        self.assertAlmostEqual(frame.iloc[1].el_deg, -2.500001)

    def test_parser_rejects_blank_ephemeris(self):
        with self.assertRaises(HorizonsError):
            parse_horizons_csv("No ephemeris")

    def test_parser_rejects_incomplete_row(self):
        with self.assertRaises(HorizonsError):
            parse_horizons_csv(CSV.replace("121.000001, -2.500001", "121.000001, n.a."))

    def test_parser_rejects_wrong_values(self):
        with self.assertRaises(HorizonsError):
            parse_horizons_csv(CSV.replace("120.000001", "361.000001"))

    def test_parser_rejects_duplicate_time(self):
        with self.assertRaises(HorizonsError):
            parse_horizons_csv(CSV.replace("2026-Nov-14 01:00", "2026-Nov-14 00:00"))

    def test_parameter_rejects_naive_times(self):
        with self.assertRaises(ValueError):
            query_params("10", SITE, datetime(2026, 11, 14), STOP, 60)

    @patch("lunar_nav.horizons.requests.get")
    def test_mock_horizons_returns_valid_grid(self, get):
        get.return_value.json.return_value = {"result": CSV}
        get.return_value.raise_for_status.return_value = None
        self.assertEqual(len(fetch_body("10", SITE, START, STOP)), 2)
        get.assert_called_once()

    @patch("lunar_nav.horizons.requests.get")
    def test_failed_nasa_request_does_not_use_demo(self, get):
        get.side_effect = ConnectionError("offline")
        with self.assertRaises(HorizonsError):
            fetch_site(SITE, START, STOP)

    @patch("lunar_nav.horizons.requests.get")
    def test_jpl_error_is_displayed(self, get):
        get.return_value.json.return_value = {"error": "invalid input"}
        with self.assertRaisesRegex(HorizonsError, "invalid input"):
            fetch_body("399", SITE, START, STOP)

    @patch("lunar_nav.horizons.requests.get")
    def test_missing_api_samples_rejected(self, get):
        short = CSV.replace("2026-Nov-14 01:00", "2026-Nov-14 00:30")
        get.return_value.json.return_value = {"result": short}
        with self.assertRaisesRegex(HorizonsError, "Wrong time grid"):
            fetch_body("10", SITE, START, STOP)

    def test_invalid_body_id_rejected(self):
        with self.assertRaises(ValueError):
            query_params("301", SITE, START, STOP, 60)

if __name__ == "__main__":
    unittest.main()
