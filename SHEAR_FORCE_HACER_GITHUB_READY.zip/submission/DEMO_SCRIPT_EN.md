# Suggested ~30-second English demo (record before submission)

**0–5 s:** “At the lunar south pole, terrain can block sunlight and Earth communications.” Show the cinematic title.

**5–11 s:** “SHE'AR FORCE compares three sample regions using NASA-derived data and 721 hourly snapshots per site.” Show the sites.

**11–20 s:** “Select a region, and move through time to see whether the Sun and Earth centers clear its modeled horizon.” Show the changing skyline/track.

**20–27 s:** “Our example model finds different visibility tradeoffs across the three locations.” Show the verdict statistics.

**27–30 s:** “Open source, transparent assumptions, and independent verification still in progress.” Show source and method links.

**Submission requirement:** Create and share a public/unlisted accessible video link **no longer than 30 seconds**, or a presentation of **up to 7 slides**. This text is a script, not a demo link.
