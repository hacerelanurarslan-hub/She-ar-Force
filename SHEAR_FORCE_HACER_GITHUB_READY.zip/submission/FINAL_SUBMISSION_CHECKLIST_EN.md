# Final NASA Space Apps submission checklist

- [ ] Have both team members join the official team/event and use the team's **Project** tab.
- [ ] Upload `index.html` (and repository files) to Hacer Elanur's public GitHub repository.
- [ ] Enable GitHub Pages and test the public site **without logging in**.
- [ ] Verify selected site, time controls, charts, and page rendering on desktop and mobile.
- [ ] Incorporate team member 1's final corrected data **before claiming scientific finality**; update embedded HTML flags, CSV files, figures and readme together.
- [ ] Audit the independent source provenance, especially NR-03 Earth 0/721 and DEM frame/observer height.
- [ ] Publish and test a **30-second maximum video** or **7-slide maximum presentation** and copy its public link.
- [ ] Paste final project summary and detailed description in **English**.
- [ ] Include both public website and GitHub source links; list all NASA and non-NASA resources and AI uses.
- [ ] Check NASA project-page required fields, terms and any official challenge-specific criteria.
- [ ] Submit on the official NASA Space Apps 2026 Project tab **before November 15, 2026 11:59 PM in your registered local event timezone**.
