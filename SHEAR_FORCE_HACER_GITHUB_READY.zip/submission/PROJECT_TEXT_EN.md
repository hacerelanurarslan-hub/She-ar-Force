# NASA Space Apps 2026 — Project submission draft (English)

> Edit with the team's actual verification status before submitting. Paste into the relevant fields on the team's official Project page. **Never describe the preliminary model as NASA-validated.**

## Title

**SHE'AR FORCE — Lunar Landing Site Navigator**

## One-sentence summary

An interactive lunar south-pole explorer that helps users compare modeled Sun visibility, Earth visibility and their overlap above the terrain skyline at three sample sites over a 30-day period.

## Project description

Lunar south-pole exploration presents a difficult tradeoff: the Sun stays low above local terrain while Earth visibility affects opportunities for direct communication. We built SHE'AR FORCE to make this tradeoff accessible to students, educators and early-stage mission concept teams.

Our cinematic, browser-based prototype visualizes three research sample points: MM-01 (Mons Mouton sample), MMP-02 (Mons Mouton Plateau sample) and NR-03 (Nobile Rim 1 vicinity sample). Users select a site and explore 721 hourly model snapshots from November 14 to December 14, 2026 (UTC). For each snapshot, modeled Sun and Earth center elevations are compared with direction-dependent terrain skyline elevations attributed by the team to NASA/JPL Horizons ephemerides and NASA LOLA-derived topography. The navigator shows whether each body center lies above the modeled skyline and reports the simultaneous-visibility percentage.

A separate Python science workspace includes the inputs, calculations, tests and historic comparisons. The project is openly documented, including method assumptions, AI assistance and areas requiring additional scientific verification. The lunar scenery and marker positions on screen are illustrative, not a georeferenced map or certified terrain survey.

## Key preliminary results

With the supplied V3 **bilinear** skyline sample model, MM-01 has both body centers visible in 388/721 hourly snapshots (53.81%), MMP-02 in 193/721 (26.77%), and NR-03 in 0/721 (0%). The NR-03 Earth-visibility result requires independent verification and is **not** asserted to be operationally accurate.

## NASA data and resources used / attributed by team

- NASA/JPL Horizons API: https://ssd-api.jpl.nasa.gov/doc/horizons.html
- NASA GSFC LOLA south-polar topography / PGDA: https://pgda.gsfc.nasa.gov/products/78
- NASA Moon Trek: https://trek.nasa.gov/moon/
- Space Apps challenge: https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/

*Confirm the NASA challenge's Resources tab and exact model input provenance before the final submission.*

## Use of AI

Claude (Anthropic) supported creation and refinement of the animated website. ChatGPT (OpenAI) supported Python pipeline and prototype code, tests, documentation, scientific communication and packaging. The student team is responsible for independent checks and final claims. All modeled numbers are team-supplied precomputed results, not synthesized by the website at runtime.

## Links — fill after publishing

- **Public live website:** https://hacerelanurarslan-hub.github.io/She-ar-Force/ (verify accessibility first)
- **Open-source repository:** https://github.com/hacerelanurarslan-hub/She-ar-Force
- **Short video / slide demo:** [TO ADD — publicly viewable video no more than 30 seconds, OR a presentation of no more than 7 slides]

## Caveats

This tool compares geometric, sampled center visibility only. It does not simulate generated power, eclipse attenuation, telecommunications link budgets, finite solar or Earth discs, terrain hazards, or landing certification. The latest dataset is preliminary until independent NASA source and DEM validation is recorded.
