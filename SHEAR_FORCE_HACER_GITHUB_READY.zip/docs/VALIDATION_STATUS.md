# Verification status — 2026-11-15

## Checks performed for the public site package

- The website embeds 3 distinct sites with 721 hourly rows each; all visibility strings have length 721.
- Every website Sun, Earth and joint visibility flag matches `science/data/v3/uc_bolge_saatlik_2163_satir.csv` for the same site and hour.
- Embedded azimuths and elevations are rounded for visual display. Original higher precision persists in the CSV. This is a presentation/transfer check, not a physics validation.
- The website can be opened as standalone HTML; no server or external data API is needed for the embedded plots. Google Fonts are optional and require internet for font loading.
- The Python science modules and their historical test suites are included, but those older tests do not certify the latest HTML interface or raw NASA model provenance.

## Still unverified

- Independent reproduction of 2026 JPL Horizons ephemerides for each site and timestamp.
- NASA LOLA input terrain tiles, coordinate frames, registration/vertical datum, local horizon profiles and lander/observer heights.
- Reason for NR-03 0 of 721 Earth visibility model results.
- End-to-end browser functionality on every supported phone/device, and public Pages publishing until enabled by the repository owner.
- Continuity of illumination, eclipses, spacecraft power production, radio link budgets, and certified terrain safety.

**Do not** claim that the web indicator `data verified` (or any similar internal message) confirms independent NASA source verification. The available checks are data integrity checks only. Team member 1 may replace this preliminary dataset after documented independent review.
