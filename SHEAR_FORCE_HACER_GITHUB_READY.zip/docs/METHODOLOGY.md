# Methodology and scientific limitations

## Sample definition

- Site coordinates and names: see `science/data/v3/uc_bolge_veri.json` and the V3 CSV.
- Three sample points: MM-01, MMP-02 and NR-03 (see README). They are **not independently confirmed mission landing sites**.
- UTC time range: 2026-11-14T00:00:00Z to 2026-12-14T00:00:00Z **inclusive**.
- Sampling: every hour = 721 sampled instants per point (720 one-hour intervals), 2163 rows total.
- Input assumptions stated in the earlier team data package: near 20 m / far 80 m LOLA-derived terrain samples; no terrain within 40 m of observer; model uses bilinear skyline as its principal example. The underlying DEM processing and ephemeris were not reproduced as a third-party audit here.

## Visibility definition

At each sampled UTC time `t`, for each target `B` (Sun or Earth):

`clearance_B(t) = target_elevation_B(t) - horizon_elevation_at_target_azimuth_B(t)`

`visible_B(t) = 1 if clearance_B(t) > 0 else 0`

`both_visible(t) = visible_Sun(t) * visible_Earth(t)`

`visibility_percent_B = 100 * sum(visible_B) / 721`

Using point **centers**, not finite solar or terrestrial apparent discs. Values rounded within website presentation must never be used to recompute near-zero visibility. Flags and accurate angles are available from the original CSV.

## Sensitivity / interpretation

The separate bilinear and nearest-pixel results are a **terrain interpolation sensitivity comparison**, not a controlled validation against ground truth. The historical V2 has different exclusion/resampling rules; its percentages are not directly comparable to V3.

**A reported run of consecutive sampled 1s is not continuous exposure.** Hourly sampling can miss short occlusions. In particular, these model percentages do not calculate solar panel energy or radio link availability; they represent only geometric, sampled body-center visibility.

The website horizon shapes and Moon scene are **procedural illustrations** built from track samples, interpolated between samples and displayed with vertical exaggeration. The foreground is not a DEM-registered landscape; location markers on the cinematic descent are schematic. Do not use them to navigate an actual lunar mission.

## Open questions before operational or scientific publication

1. Verify the exact NASA/JPL Horizons query, target and observer body IDs, longitudes, UTC time grid and reference frames against independent tool output.
2. Confirm NASA LOLA DEM product ID, provenance, registration, vertical datum, sample coordinates, site height, and local horizon ray tracing (especially NR-03 Earth 0/721).
3. Perform horizon azimuth resolution, near-field exclusion, observer-height and resampling sensitivity tests.
4. Compare hourly results against higher-rate time grids at transitions; model solar/terrestrial disc extents and eclipses if required.
5. Add terrain slope/roughness and lander engineering constraints before making a landing safety claim.

This is a transparent research prototype and educational comparison, not a NASA-certified result.
