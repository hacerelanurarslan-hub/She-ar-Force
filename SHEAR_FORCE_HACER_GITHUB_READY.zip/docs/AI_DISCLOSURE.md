# AI use disclosure

SHE'AR FORCE used **Anthropic Claude** to produce and refine the cinematic HTML/CSS/JavaScript website using team-supplied V3 numeric records, and **OpenAI ChatGPT** to help implement earlier Python/Streamlit prototypes, scientific processing scaffolding, tests, documentation, integration, packaging and quality checks.

Human team members choose the scientific assumptions, sites, presentation choices and eventual submission and are responsible for auditing AI-generated code and data claims. No AI model independently certifies the NASA/JPL Horizons or LOLA provenance of the packaged experimental results.

The current website uses **procedural computer graphics**, not photographic or georeferenced DEM rendering. These scenes must not be mistaken for accurately registered lunar landscape evidence. It does not embed third-party or AI-generated image files. Other earlier prototype materials may use illustrative images; they are **not** included in the published homepage.

NASA and the United States Geological Survey are not affiliated with or endorsing this independent student prototype.
