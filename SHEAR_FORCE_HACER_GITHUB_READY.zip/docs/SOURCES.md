# Sources and attributions

NASA Space Apps 2026 requires explicit references for resources, tools, third-party code and data used. This file records the intended source provenance, not proof that every upstream model query has been independently reproduced.

## Primary data and challenge

- [2026 Lunar Landing Site Navigator challenge](https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/) — challenge definition, objective and official resource list.
- [NASA/JPL Horizons API documentation](https://ssd-api.jpl.nasa.gov/doc/horizons.html) — apparent Sun/Earth azimuth and elevation positions for lunar observer.
- [NASA/JPL Horizons Manual](https://ssd.jpl.nasa.gov/horizons/manual.html) — observer, target and reference-frame conventions.
- [NASA GSFC Planetary Geodynamics Data Archive — LOLA lunar south-polar topography](https://pgda.gsfc.nasa.gov/products/78) — terrain height input attributed by the team.
- [LOLA PDS archive](https://imbrium.mit.edu/) — mission data archive.
- [NASA Moon Trek](https://trek.nasa.gov/moon/) — lunar exploration reference.

## Implementation and reviews

- [GitHub Pages](https://docs.github.com/en/pages) — public hosting.
- [Python](https://www.python.org/), [Streamlit](https://streamlit.io/), [NumPy](https://numpy.org/), [pandas](https://pandas.pydata.org/), [Plotly](https://plotly.com/python/) and [requests](https://requests.readthedocs.io/) — optional scientific application.
- [Claude — Anthropic](https://www.anthropic.com/claude) and [ChatGPT — OpenAI](https://openai.com/chatgpt/) — AI-assisted website, code, debugging and documentation. See `AI_DISCLOSURE.md`.

## Attribution caveat

The team-supplied V3 model records are included for reproducibility of the **presentation**. The upstream NASA ephemerides / LOLA extraction query parameters, DEM pixel provenance and georeferencing still require final independent verification and may be updated by the team. References above indicate the claimed source datasets, not NASA review or endorsement of these specific numeric outputs.
