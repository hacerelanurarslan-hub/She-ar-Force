# Third-party software and data

Apache-2.0 in this repository applies to the project's original code and documentation **only**. It does **not** relicense NASA/JPL data, NASA GSFC LOLA topography, published papers, external website content, Google Fonts, or software dependencies.

- [JPL Horizons](https://ssd.jpl.nasa.gov/horizons/) — ephemeris reference.
- [NASA LOLA / PGDA](https://pgda.gsfc.nasa.gov/products/78) — original lunar topography source attributed by team.
- [Google Fonts](https://fonts.google.com/) — CSS web-font service (Barlow Condensed, Inter, IBM Plex Mono); font files are not redistributed in this repository.
- [Streamlit](https://github.com/streamlit/streamlit), [NumPy](https://github.com/numpy/numpy), [pandas](https://github.com/pandas-dev/pandas), [Plotly](https://github.com/plotly/plotly.py), [requests](https://github.com/psf/requests) — optional Python dependencies, distributed separately by package managers.

All external sources require proper credit under the NASA Space Apps [terms](https://www.spaceappschallenge.org/legal/). No endorsement by NASA is implied.
