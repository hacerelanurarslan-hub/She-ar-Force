# Publishing this repository with GitHub Pages

**Repository owner:** `hacerelanurarslan-hub`  
**Repository name:** `She-ar-Force`  
**Expected Pages URL after publication:** https://hacerelanurarslan-hub.github.io/She-ar-Force/

1. Log into GitHub as `hacerelanurarslan-hub` and open https://github.com/hacerelanurarslan-hub/She-ar-Force.
2. Make sure this **unpacked repository contents** — notably `index.html` at the top level — are uploaded to the `main` branch. Upload the folder **contents**, not the ZIP file itself.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**; select `main` and `/(root)`; click **Save**.
5. Open **Actions** to check the GitHub Pages deployment; then visit the published address above in an incognito window.
6. Confirm the animation works, the three site buttons work, and the page is accessible without login. GitHub Pages does not execute the optional Python scripts; the website is pure static HTML/JS.
7. Put both the public website URL and the GitHub source URL on the official NASA Space Apps **Project** submission page. Also provide the separate short-demo link.

References: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site and https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
